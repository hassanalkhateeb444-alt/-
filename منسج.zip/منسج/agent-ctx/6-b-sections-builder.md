# Task 6-b — Work Record: Portfolio / Team / FAQ / Contact / Footer

**Agent:** sections-builder (task 6-b)
**Date:** build session, Mansaj Digital one-page site
**Status:** ✅ Complete — lint clean, `tsc --noEmit` clean for all 5 files

## Files created (exactly 5, no others touched)

| File | Export | Section id |
|---|---|---|
| `src/components/mansaj/portfolio.tsx` | `PortfolioSection` | `portfolio` |
| `src/components/mansaj/team.tsx` | `TeamSection` | `team` |
| `src/components/mansaj/faq.tsx` | `FaqSection` | `faq` |
| `src/components/mansaj/contact-cta.tsx` | `ContactSection` | `contact` |
| `src/components/mansaj/site-footer.tsx` | `SiteFooter` | — (footer element, `mt-auto` built in) |

## What was built

### portfolio.tsx
- Eyebrow «أعمال منسج», H2 «مشاريع منسج على أرض الواقع», intro — verbatim from plan «قسم الأعمال».
- 7 projects with names verbatim from the plan (incl. «JUST WOW – واو وبس» with the en-dash).
- **All 7 testimonials copied VERBATIM from «التقييمات المقدمة من منسج»** — verified programmatically (exact string match, emoji ❤️ 🌷 👏 😍 preserved). English translations written by me (per conventions).
- Squared filter chips (الكل / مطاعم ومشويات / مكاتب وقانونية / عقارات) with counts, `aria-pressed`, instant `useState` filtering.
- Typographic cards (no fake screenshots): tinted decorative band per category (`brand-soft` / `secondary` / `cream`, no blue) with pure-CSS mosaic squares + `bg-blueprint-solid`, mono index `01–07`, category chip with square marker, `line-clamp-2 min-h` name for uniform card height, no horizontal overflow.
- Cards are `<article>` + stretched overlay `<button>` (valid HTML, a11y aria-label per project).
- Controlled shadcn Dialog: category (DialogDescription), name (DialogTitle), «تقييم صاحب المشروع» label + styled blockquote (`border-s-2 ps-4`), CTA «أريد موقعًا مشابهًا لمشروعي» → `openRequest()`. Dialog has `max-h-[85dvh] overflow-y-auto`.

### team.tsx
- H2 «وراء منسج فريق يعمل على تحويل الفكرة إلى تجربة.» (verbatim).
- Brand card «منسج الرقمية»: `bg-deep` + blueprint overlay + MosaicMark, cream tile logo using the exact `dark:hidden`/`dark:block` dual-Image pattern from site-header.tsx, line «نبني حضورك على الويب: من فهم الاحتياج إلى التسليم والدعم.»
- Hasan card: real photo `/images/hasan.jpg` (`next/image` fill + `sizes="160px"` + object-cover, squared `rounded-sm`). Alawi card: squared deep-teal initials block («ع» / "A").
- «تعرّف على … أكثر» opens Dialog: name, role, role description, focus bullets ONLY from approved wording (Hasan: فهم احتياج المشروع / تنسيق العمل ومتابعة التنفيذ / التواصل مع أصحاب المشاريع; Alawi: تنفيذ مشاريع الويب / تطوير وتحسين المواقع — **no invented skills/tech**), WhatsApp button from `CONTACTS`.

### faq.tsx
- Eyebrow «أسئلة شائعة», H2 «إجابات قصيرة قبل أن تبدأ», shadcn Accordion (single, collapsible), 6 honest Q&As exactly as briefed — no invented prices/timelines. Mono `01–06` markers, squared bordered items, `text-start` override on trigger (twMerge wins over base `text-left`), `last:border-b` to keep full borders.

### contact-cta.tsx
- Deep-teal CTA panel (`bg-deep text-deep-foreground`, `bg-blueprint` overlay, MosaicMark + CSS mosaic accents): H2 «جاهز تطوّر حضور مشروعك؟» + paragraph verbatim, primary brand button «ابدأ باختيار الخدمة» → `openRequest()`, help line «لا تعرف أي خدمة تناسبك؟ اختر «ساعدوني في الاختيار» في النموذج.» verbatim.
- Two contact cards (Hasan/Alawi from `CONTACTS`): squared avatar/photo, role, phone `dir="ltr"` mono, per-person `https://wa.me/{wa}` button (target _blank, rel noopener noreferrer) with `WhatsAppIcon`.
- Instagram card: lucide `Instagram` icon, `@mansagdigital` (`dir="ltr"`, from `BRAND`), label «حساب منسج الرقمية الرسمي على إنستغرام — تابع أعمالنا الجديدة» → links to `BRAND.instagram`.

### site-footer.tsx
- Plain `<footer className="mt-auto …">` (no fixed positioning), `border-t-2 border-brand/50 bg-deep text-deep-foreground`.
- Cream-tile dual logo, line «مشروعك يستحق موقعًا يعمل لأجله.», anchor buttons (الخدمات/الأعمال/طريقة العمل/الفريق/تواصل) via `scrollToSection`, both WhatsApp phones, Instagram link labeled **«الحساب الرسمي لعلامة منسج الرقمية» / "The official account of Mansaj Digital"**.
- Bottom bar: `© {year} منسج الرقمية — Mansaj Digital` + «صُنع بعناية من فريق منسج», with safe-area padding.

## Client-context compliance
- ✅ Instagram labeled as the **brand's official account** (both contact card wording and footer wording); never tied to Hasan personally.
- ✅ 7 testimonials verbatim (automated exact-match check passed).
- ✅ No project URLs / no "visit website" links anywhere.
- ✅ No invented team skills/technologies.
- ✅ No blue/indigo, no rounded-full chips/cards; RTL-safe `ms/me/ps/pe/start/end` only (grep-verified: zero `ml/mr/pl/pr`).

## Deviations (minor, with reasons)
1. **Safe-area**: used `pb-[max(1.25rem,env(safe-area-inset-bottom))]` instead of bare `pb-[env(safe-area-inset-bottom)]` so the bar keeps base padding when the env is 0 (bare env() would collapse padding to 0 on desktop).
2. **Team section eyebrow** «الفريق» / "The team" added (not in brief) for consistency with other sections that use `SectionHeading` eyebrows.
3. **Portfolio card click pattern**: whole card is clickable via a stretched overlay `<button>` (instead of `<button>` wrapping `<h3>`) to keep valid HTML content models; hint text «عرض تقييم صاحب المشروع» makes it clear the card leads to the owner's feedback, not a live site (no fake URLs allowed).
4. **English project names** are careful transliterations (e.g., "Al-Hamra Grills", "Law Office of Aisha Mohammed Al-Sayari") since the plan provides none.

## Verification
- `bun run lint 2>&1 | grep -E "(portfolio|team|faq|contact-cta|site-footer)"` → **CLEAN** (the 2 remaining project lint errors are pre-existing in `shared.tsx` / `lang.tsx` / `request-form.tsx`, files this task does not own).
- `bunx tsc --noEmit` → no errors in any of the 5 files.
- Dev server compiles cleanly (`dev.log` shows ✓ Compiled, no warnings from my files).
- Note for the page-assembly agent: import order suggestion — `PortfolioSection`, `TeamSection`, `FaqSection`, `ContactSection`, `SiteFooter` (ids: `portfolio`, `team`, `faq`, `contact` already match `site-header.tsx` NAV_ITEMS).
