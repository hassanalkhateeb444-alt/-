# Task 6-a — Work Record (Mansaj sections: why-site / why-mansaj / services / process)

**Agent:** Z.ai Code (task id 6-a)
**Status:** ✅ Completed
**Date:** 2026-02-19

## Files created (exactly 4 — no other files touched)

| File | Exported component | Section id |
|---|---|---|
| `src/components/mansaj/why-site.tsx` | `WhySiteSection` (client) | `why-site` |
| `src/components/mansaj/why-mansaj.tsx` | `WhyMansajSection` (client) | `why-mansaj` |
| `src/components/mansaj/services.tsx` | `ServicesSection` (client) | `services` |
| `src/components/mansaj/process.tsx` | `ProcessSection` (client) | `process` |

## What was built

### why-site.tsx
- `Section` + `Container` + `SectionHeading` from `shared.tsx`.
- Two-column on `lg`: text at start (right in RTL), CSS-only "website mockup" visual at end. Mockup = pure divs: browser bar with squared window chips, site header with **two small squares like the logo** (ink + brand), hero block, 3-card content mosaic, contact strip, mosaic backdrop squares, `shadow-[8px_8px_0_0_var(--brand-soft)]` offset accent.
- 4 verbatim bullets with lucide icons (`LayoutGrid`, `Clock`, `Layers`, `MessageSquare`) inside squared `bg-brand-soft` 9×9 containers — geometric square bullets, no circles.
- CTA `Button` «اكتشف الموقع المناسب لنشاطي» → `openRequest()`; dir-flipping arrow (ArrowLeft in RTL / ArrowRight in LTR).

### why-mansaj.tsx
- Heading block on the page background via `SectionHeading` (keeps token-based contrast), then a **full-bleed `bg-deep text-deep-foreground` trust panel** with a subtle `bg-blueprint` overlay (opacity-60), `MosaicMark` corner accent, and the 4 `STATS` blocks.
- Stat blocks: squared borders (`border-deep-foreground/15`), small brand square marker, `CountUp` numbers (150+, 150, 1+, 356) at `text-3xl sm:text-4xl text-brand` (large bold text ⇒ passes AA-large on deep in both themes; verified ratios ~4.1:1 light / ~8.4:1 dark), labels via `t({ ar: s.ar, en: s.en })` in `text-deep-foreground/80` (~7.6:1 light, better dark).
- Contrast check for both themes: blueprint lines use `var(--border)` (beige in light, white/9% in dark) — subtle on deep in both.

### services.tsx
- All 11 `SERVICES` from `data.ts`; grid `1 / sm:2 / lg:3`.
- Cards: `group flex flex-col border border-border bg-card p-5 transition-all hover:border-brand hover:shadow-[4px_4px_0_0_var(--brand)]` (+ `focus-within` equivalents). Squared icon container `bg-brand-soft text-foreground` (flips correctly in dark: `#123c3b` + light foreground).
- Title `min-h-12` + description `line-clamp-3` + `mt-auto` button ⇒ aligned rows, no overflow.
- Card CTA: shadcn `Button variant="outline"`, squared (`rounded-none`), `h-11` (≥44px touch target), label «أريد هذه الخدمة» / "I want this service" → `openRequest({ serviceId: svc.id })`.

### process.tsx
- 5 verbatim steps. Numbers `01`–`05` in squared `h-14 w-14 bg-deep text-deep-foreground font-mono` blocks, `dir="ltr"`, `border border-border`, static brand offset shadow `shadow-[3px_3px_0_0_var(--brand)]` — never circles.
- Mobile/tablet: vertical stepped path — absolute connector segments (`absolute -bottom-8 start-7 top-14 w-px bg-border lg:hidden`) join number centers through the grid gap; content indented `ps-[4.5rem]` so text never crosses the rail.
- lg: `grid-cols-5` row; per-step `h-px flex-1 bg-border lg:-me-4` connector spans the column gap so the thin line runs number→number continuously; last step has no connector.

## Arabic copy — verbatim confirmation
All Arabic strings were copied **verbatim** from `upload/خطة بناء موقع منسج الرقمية.md`:
- «لماذا يحتاج مشروعك إلى موقع؟» / «لأن عملاءك يريدون أن يجدوا إجاباتهم بسهولة.» / main paragraph + 4 bullets + «اكتشف الموقع المناسب لنشاطي» (plan §6).
- «لماذا منسج؟» / «لا نبني صفحات فقط؛ نبني تجربة تناسب هدف مشروعك.» / paragraph (plan §6); stat labels come from `STATS` in `data.ts` (already plan-derived).
- «الخدمات» / «اختر ما يحتاجه مشروعك، لا ما يبدو رائجًا فقط.» / intro + «أريد هذه الخدمة» (plan §6); service titles/descriptions come from `SERVICES` in `data.ts` (already plan-derived).
- «طريقة العمل» / «واضحين معك من أول خطوة» + the 5 steps with their descriptions (plan §6).
English copy is my own concise professional translation.

## Conventions compliance
- `"use client";` first line in all 4 files; `useLang()` imported from `@/lib/lang`; all copy via `t({ar, en})`.
- RTL-safe only: `ms-/me-/ps-/pe-/start-/end-/text-start` used; no `ml/mr/pl/pr/left/right` for direction; arrows flip via `dir`.
- Motion: `fade()` helper copied from hero.tsx pattern, adapted to `whileInView` + `viewport={{ once: true, margin: "-60px" }}` (below-the-fold sections), guarded by `useReducedMotion()` → `{}` when reduced. Subtle 18px y-fade only.
- No blue/indigo, no rounded-full, geometric aesthetic, hover-shadow idiom reused, trust chips are small squares.
- No images used (why-site visual is CSS-only, per spec).

## Deviations (and why)
1. **why-mansaj heading sits on the page background, only the stats band is the deep full-bleed strip.** Reason: `SectionHeading` hardcodes `text-muted-foreground` for the description, which fails contrast on `bg-deep` in light mode (~2.3:1). Keeping the heading on the normal background preserves the mandated `SectionHeading` usage AND the "trust panel" deep strip with correct contrast in both themes (task wording was "consider … full-bleed strip", and explicitly required correct contrast).
2. **Stat number color is `text-brand`** (large bold text): on `--deep` in light mode it is ~4.08:1 which passes AA for large text (≥3:1); labels use `deep-foreground/80` for full AA small-text compliance.
3. Process connectors are per-step segments (absolute vertical on mobile, flex horizontal on lg) instead of one continuous rail — gives pixel-exact joins in both directions while staying 100% RTL-safe.

## Verification
- `bun run lint 2>&1 | grep -E "(why-site|why-mansaj|services|process)" || echo CLEAN` → **CLEAN** (no lint issues in my files).
- `bunx tsc --noEmit` filtered to my files → **TS-CLEAN**.
- Note for next agents: `bun run lint` reports 2 **pre-existing** errors in files I do not own: `src/components/mansaj/shared.tsx:171` and `src/lib/lang.tsx:36` (`react-hooks/set-state-in-effect` in `CountUp` and `LanguageProvider`). I did not touch them per the ownership rule; the owners may want to refactor (e.g., `useSyncExternalStore` or moving the setState out of the effect body).

## Integration notes
- All sections are drop-in: compose them in `page.tsx` in order `WhySiteSection → WhyMansajSection → ServicesSection → ProcessSection` (each brings its own `Section` wrapper + anchor id).
- `openRequest()` events (`mansaj:start-request`, with optional `{ serviceId }`) are consumed by the existing `request-form.tsx` listener — no wiring needed.
