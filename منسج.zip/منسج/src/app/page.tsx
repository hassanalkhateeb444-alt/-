"use client";

import { useState } from "react";
import { SiteHeader } from "@/components/mansaj/site-header";
import { Hero } from "@/components/mansaj/hero";
import { WhySiteSection } from "@/components/mansaj/why-site";
import { WhyMansajSection } from "@/components/mansaj/why-mansaj";
import { ServicesSection } from "@/components/mansaj/services";
import { PortfolioSection } from "@/components/mansaj/portfolio";
import { ProcessSection } from "@/components/mansaj/process";
import { TeamSection } from "@/components/mansaj/team";
import { FaqSection } from "@/components/mansaj/faq";
import { ContactSection } from "@/components/mansaj/contact-cta";
import { SiteFooter } from "@/components/mansaj/site-footer";
import { RequestForm } from "@/components/mansaj/request-form";
import { NavDock } from "@/components/mansaj/nav-dock";
import { CustomCursor } from "@/components/mansaj/custom-cursor";

export default function Home() {
  const [formOpen, setFormOpen] = useState(false);

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <NavDock />
      <CustomCursor />
      <main className="flex-1">
        <Hero />
        <WhySiteSection />
        <WhyMansajSection />
        <ServicesSection />
        <PortfolioSection />
        <ProcessSection />
        <TeamSection />
        <FaqSection />
        <ContactSection />
      </main>
      <SiteFooter />
      <RequestForm open={formOpen} onOpenChange={setFormOpen} />
    </div>
  );
}
