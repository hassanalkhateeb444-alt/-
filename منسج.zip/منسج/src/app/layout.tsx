import type { Metadata, Viewport } from "next";
import { IBM_Plex_Sans_Arabic } from "next/font/google";
import { ThemeProvider } from "next-themes";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { LanguageProvider } from "@/lib/lang";

const plexArabic = IBM_Plex_Sans_Arabic({
  variable: "--font-plex-arabic",
  subsets: ["arabic", "latin"],
  weight: ["300", "400", "500", "600", "700"],
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL("https://mansaj.digital"),
  title: "منسج الرقمية | Mansaj Digital — نبني حضورك على الويب",
  description:
    "نصمّم ونطوّر مواقع ومتاجر وتجارب رقمية تساعد عملاءك على فهم ما تقدمه والوصول إليك واتخاذ الخطوة التالية بسهولة. أكثر من 150 موقعًا خلال السنة الماضية.",
  keywords: [
    "منسج الرقمية",
    "تصميم مواقع",
    "متاجر إلكترونية",
    "صفحات هبوط",
    "Mansaj Digital",
    "web development",
    "Yemen web design",
  ],
  authors: [{ name: "Mansaj Digital" }],
  openGraph: {
    title: "منسج الرقمية | Mansaj Digital",
    description:
      "مشروعك يستحق موقعًا يعمل لأجله. مواقع تعريفية، متاجر، صفحات هبوط، ومواقع حجز — نبني حضورك على الويب.",
    type: "website",
    locale: "ar_YE",
    alternateLocale: "en_US",
    images: [{ url: "/images/og-image.jpg", width: 1200, height: 630, alt: "Mansaj Digital" }],
  },
  twitter: {
    card: "summary_large_image",
    title: "منسج الرقمية | Mansaj Digital",
    description: "مشروعك يستحق موقعًا يعمل لأجله.",
    images: ["/images/og-image.jpg"],
  },
};

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#faf8f1" },
    { media: "(prefers-color-scheme: dark)", color: "#0b2426" },
  ],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar" dir="rtl" suppressHydrationWarning>
      <body className={`${plexArabic.variable} antialiased bg-background text-foreground`}>
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          <LanguageProvider>{children}</LanguageProvider>
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  );
}
