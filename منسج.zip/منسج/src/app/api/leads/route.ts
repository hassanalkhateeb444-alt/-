import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";

const leadSchema = z.object({
  name: z.string().trim().min(2).max(80),
  business: z.string().trim().min(2).max(120),
  city: z.string().trim().min(2).max(80),
  services: z.string().trim().min(1).max(500),
  description: z.string().trim().min(5).max(2000),
  currentSite: z.string().trim().max(300).nullable().optional(),
  preferredTime: z.string().trim().max(120).nullable().optional(),
  contactTarget: z.enum(["hasan", "alawi"]),
  lang: z.enum(["ar", "en"]).default("ar"),
});

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const parsed = leadSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ ok: false, error: "VALIDATION" }, { status: 400 });
    }
    const lead = await db.lead.create({
      data: {
        name: parsed.data.name,
        business: parsed.data.business,
        city: parsed.data.city,
        services: parsed.data.services,
        description: parsed.data.description,
        currentSite: parsed.data.currentSite || null,
        preferredTime: parsed.data.preferredTime || null,
        contactTarget: parsed.data.contactTarget,
        lang: parsed.data.lang,
      },
    });
    return NextResponse.json({ ok: true, id: lead.id });
  } catch {
    return NextResponse.json({ ok: false, error: "SERVER" }, { status: 500 });
  }
}
