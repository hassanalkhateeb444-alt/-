"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useSyncExternalStore,
} from "react";

export type Lang = "ar" | "en";
export type Dir = "rtl" | "ltr";

const STORAGE_KEY = "mansaj-lang";

/* ------------------------------------------------------------------ */
/* External store around localStorage (hydration-safe, lint-safe)      */
/* ------------------------------------------------------------------ */

let cachedLang: Lang | null = null;
const listeners = new Set<() => void>();

function readLang(): Lang {
  try {
    const v = window.localStorage.getItem(STORAGE_KEY);
    return v === "en" ? "en" : "ar";
  } catch {
    return "ar";
  }
}

function getSnapshot(): Lang {
  if (cachedLang === null) cachedLang = readLang();
  return cachedLang;
}

const getServerSnapshot = (): Lang => "ar";

function subscribe(cb: () => void): () => void {
  listeners.add(cb);
  const onStorage = (e: StorageEvent) => {
    if (e.key === STORAGE_KEY) {
      cachedLang = null;
      cb();
    }
  };
  window.addEventListener("storage", onStorage);
  return () => {
    listeners.delete(cb);
    window.removeEventListener("storage", onStorage);
  };
}

function writeLang(l: Lang) {
  try {
    window.localStorage.setItem(STORAGE_KEY, l);
  } catch {
    /* ignore */
  }
  cachedLang = l;
  listeners.forEach((cb) => cb());
}

/* ------------------------------------------------------------------ */
/* Context                                                             */
/* ------------------------------------------------------------------ */

interface LangContextValue {
  lang: Lang;
  dir: Dir;
  setLang: (l: Lang) => void;
  toggle: () => void;
  /** Pick between Arabic and English values: t({ ar: "نص", en: "text" }) */
  t: <T>(strings: { ar: T; en: T }) => T;
}

const LangContext = createContext<LangContextValue | null>(null);

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const lang = useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);

  // Keep <html lang/dir> in sync (DOM side effect only — no setState).
  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
  }, [lang]);

  const setLang = useCallback((l: Lang) => writeLang(l), []);
  const toggle = useCallback(() => {
    writeLang(getSnapshot() === "ar" ? "en" : "ar");
  }, []);
  const t = useCallback(
    <T,>(strings: { ar: T; en: T }): T => (lang === "ar" ? strings.ar : strings.en),
    [lang]
  );

  const value = useMemo<LangContextValue>(
    () => ({ lang, dir: lang === "ar" ? "rtl" : "ltr", setLang, toggle, t }),
    [lang, setLang, toggle, t]
  );

  return <LangContext.Provider value={value}>{children}</LangContext.Provider>;
}

export function useLang(): LangContextValue {
  const ctx = useContext(LangContext);
  if (!ctx) throw new Error("useLang must be used within <LanguageProvider>");
  return ctx;
}
