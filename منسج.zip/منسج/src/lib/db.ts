import { PrismaClient } from '@prisma/client'

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

/**
 * Prisma client with a safe fallback URL.
 * Locally DATABASE_URL comes from .env. On hosting platforms (e.g. Netlify)
 * where the variable may not be configured yet, the fallback keeps the
 * module import (and therefore the build) from crashing — queries will
 * simply fail gracefully and the API route returns a 503.
 */
function createPrismaClient(): PrismaClient {
  return new PrismaClient({
    log: ['query'],
    datasourceUrl: process.env.DATABASE_URL ?? 'file:./db/custom.db',
  })
}

export const db =
  globalForPrisma.prisma ?? createPrismaClient()

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = db
