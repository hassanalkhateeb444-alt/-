"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Image from "next/image";
import {
  ArrowLeft,
  ArrowRight,
  Check,
  ChevronLeft,
  ChevronRight,
  LifeBuoy,
  MessageSquareText,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useLang } from "@/lib/lang";
import { cn } from "@/lib/utils";
import {
  CONTACTS,
  DOMAINS,
  SERVICES,
  type ContactId,
  type DomainId,
  type ServiceId,
} from "./data";
import { openRequest, WhatsAppIcon, type RequestDetail } from "./shared";

/* ------------------------------------------------------------------ */
/* Types & constants                                                   */
/* ------------------------------------------------------------------ */

const TOTAL_STEPS = 4; // domain → services → details → contact (review comes after)

interface FormState {
  domain: DomainId | null;
  services: ServiceId[];
  helpMe: boolean;
  name: string;
  business: string;
  city: string;
  description: string;
  currentSite: string;
  preferredTime: string;
  target: ContactId | null;
}

const EMPTY_STATE: FormState = {
  domain: null,
  services: [],
  helpMe: false,
  name: "",
  business: "",
  city: "",
  description: "",
  currentSite: "",
  preferredTime: "",
  target: null,
};

/* ------------------------------------------------------------------ */
/* Component                                                           */
/* ------------------------------------------------------------------ */

export function RequestForm({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
}) {
  const { t, lang, dir } = useLang();
  const { toast } = useToast();
  const [step, setStep] = useState(0); // 0..3 steps, 4 = review
  const [state, setState] = useState<FormState>(EMPTY_STATE);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [sending, setSending] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const BackArrow = dir === "rtl" ? ArrowRight : ArrowLeft;
  const FwdChevron = dir === "rtl" ? ChevronLeft : ChevronRight;

  const set = <K extends keyof FormState>(key: K, value: FormState[K]) => {
    setState((s) => ({ ...s, [key]: value }));
    setErrors((e) => {
      if (!e[key as string]) return e;
      const next = { ...e };
      delete next[key as string];
      return next;
    });
  };

  const resetAll = useCallback(() => {
    setStep(0);
    setState(EMPTY_STATE);
    setErrors({});
    setSending(false);
  }, []);

  /* --- open via event (from hero, header, service cards, CTA...) --- */
  useEffect(() => {
    const handler = (ev: Event) => {
      const detail = (ev as CustomEvent<RequestDetail>).detail ?? {};
      setState((s) => {
        const next = { ...s };
        if (detail.domain) next.domain = detail.domain as DomainId;
        if (detail.serviceId) {
          const svc = SERVICES.find((x) => x.id === detail.serviceId);
          const host = DOMAINS.find((d) =>
            d.services.includes(detail.serviceId as ServiceId)
          );
          if (svc && host) {
            next.domain = host.id;
            next.services = [svc.id];
          }
        }
        return next;
      });
      setStep(detail.serviceId ? 1 : detail.domain ? 1 : 0);
      setErrors({});
      onOpenChange(true);
    };
    window.addEventListener("mansaj:start-request", handler);
    return () => window.removeEventListener("mansaj:start-request", handler);
  }, [onOpenChange]);

  /* --- reset after close --- */
  const handleOpenChange = (v: boolean) => {
    onOpenChange(v);
    if (!v) window.setTimeout(resetAll, 250);
  };

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: 0 });
  }, [step]);

  /* ------------------------------ validation ------------------------------ */
  const validate = (s: number): boolean => {
    const e: Record<string, string> = {};
    if (s === 0 && !state.domain) {
      e.domain = t({ ar: "اختر مجال نشاطك للمتابعة.", en: "Choose your business field to continue." });
    }
    if (s === 1 && state.services.length === 0 && !state.helpMe) {
      e.services = t({
        ar: "اختر خدمة واحدة على الأقل، أو اطلب مساعدتنا في الاختيار.",
        en: "Pick at least one service, or ask us to help you choose.",
      });
    }
    if (s === 2) {
      if (state.name.trim().length < 2)
        e.name = t({ ar: "اكتب اسمك من فضلك.", en: "Please write your name." });
      if (state.business.trim().length < 2)
        e.business = t({ ar: "اكتب اسم النشاط أو المشروع.", en: "Write your business or project name." });
      if (state.city.trim().length < 2)
        e.city = t({ ar: "اكتب المدينة أو البلد.", en: "Write the city or country." });
      if (state.description.trim().length < 10)
        e.description = t({
          ar: "اكتب وصفًا مختصرًا لفكرتك (10 أحرف على الأقل).",
          en: "Write a short description (at least 10 characters).",
        });
    }
    if (s === 3 && !state.target) {
      e.target = t({ ar: "اختر جهة التواصل للمتابعة.", en: "Choose who to talk to, to continue." });
    }
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const next = () => {
    if (!validate(step)) return;
    setStep((p) => Math.min(4, p + 1));
  };
  const back = () => setStep((p) => Math.max(0, p - 1));

  /* --------------------------- WhatsApp message --------------------------- */
  const domainLabel = state.domain
    ? t({
        ar: DOMAINS.find((d) => d.id === state.domain)?.ar ?? "",
        en: DOMAINS.find((d) => d.id === state.domain)?.en ?? "",
      })
    : "";

  const servicesLabel =
    state.services.length > 0
      ? state.services
          .map((id) => {
            const svc = SERVICES.find((s) => s.id === id);
            return svc ? t({ ar: svc.ar, en: svc.en }) : "";
          })
          .filter(Boolean)
          .join(t({ ar: "، ", en: ", " }))
      : "";

  const target = state.target ? CONTACTS[state.target] : null;

  const buildMessage = (): string => {
    if (!target) return "";
    if (lang === "ar") {
      const lines = [
        `مرحبًا ${target.ar}، وصلت إليكم من موقع منسج الرقمية.`,
        `اسمي ${state.name.trim()}، واسم النشاط ${state.business.trim()} في ${state.city.trim()}.`,
        `أبحث عن: ${servicesLabel || "مساعدة في اختيار الخدمة المناسبة"}.`,
        `تفاصيل مشروعي: ${state.description.trim()}`,
      ];
      if (state.currentSite.trim()) lines.push(`الموقع الحالي إن وجد: ${state.currentSite.trim()}`);
      if (state.preferredTime.trim()) lines.push(`أفضل وقت للتواصل: ${state.preferredTime.trim()}`);
      return lines.join("\n");
    }
    const lines = [
      `Hello ${target.en}, I'm reaching out from the Mansaj Digital website.`,
      `My name is ${state.name.trim()}, my business is ${state.business.trim()} in ${state.city.trim()}.`,
      `I'm looking for: ${servicesLabel || "help choosing the right service"}.`,
      `Project details: ${state.description.trim()}`,
    ];
    if (state.currentSite.trim()) lines.push(`Current website: ${state.currentSite.trim()}`);
    if (state.preferredTime.trim()) lines.push(`Best time to contact: ${state.preferredTime.trim()}`);
    return lines.join("\n");
  };

  const submit = async () => {
    if (!target) return;
    setSending(true);
    // Best-effort lead logging — never blocks the user from reaching WhatsApp.
    try {
      await fetch("/api/leads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: state.name.trim(),
          business: state.business.trim(),
          city: state.city.trim(),
          services:
            servicesLabel + (state.helpMe ? (lang === "ar" ? " + مساعدة في الاختيار" : " + help choosing") : ""),
          description: state.description.trim(),
          currentSite: state.currentSite.trim() || null,
          preferredTime: state.preferredTime.trim() || null,
          contactTarget: target.id,
          lang,
        }),
      });
    } catch {
      /* ignore — WhatsApp remains the primary action */
    }
    const url = `https://wa.me/${target.wa}?text=${encodeURIComponent(buildMessage())}`;
    window.open(url, "_blank", "noopener,noreferrer");
    setSending(false);
    toast({
      title: t({ ar: "جهّزنا رسالتك ✅", en: "Your message is ready ✅" }),
      description: t({
        ar: "افتح واتساب واضغط إرسال داخل التطبيق لإكمال المحادثة.",
        en: "Open WhatsApp and press send inside the app to continue the chat.",
      }),
    });
    handleOpenChange(false);
  };

  /* ------------------------------ small UI ------------------------------ */
  const fieldError = (key: string) =>
    errors[key] ? (
      <p role="alert" className="mt-1.5 text-xs font-medium text-destructive">
        {errors[key]}
      </p>
    ) : null;

  const stepTitles = [
    t({ ar: "ما مجال نشاطك؟", en: "What is your business field?" }),
    t({ ar: "ما الخدمات التي تحتاجها؟", en: "Which services do you need?" }),
    t({ ar: "أخبرنا عن مشروعك", en: "Tell us about your project" }),
    t({ ar: "مع من تحب أن تتحدث؟", en: "Who would you like to talk to?" }),
  ];

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent
        dir={dir}
        className="max-h-[92dvh] overflow-y-auto p-0 sm:max-w-xl"
        ref={scrollRef as React.Ref<HTMLDivElement>}
      >
        <div className="sticky top-0 z-10 border-b border-border bg-background/95 px-5 pb-4 pt-5 backdrop-blur sm:px-6">
          <DialogHeader className="space-y-1 text-start">
            <DialogTitle className="flex items-center gap-2 text-lg font-bold">
              <MessageSquareText className="h-5 w-5 text-brand" aria-hidden="true" />
              {step < 4
                ? stepTitles[step]
                : t({ ar: "المراجعة النهائية", en: "Final review" })}
            </DialogTitle>
            <DialogDescription className="text-sm text-muted-foreground">
              {step < 4
                ? t(
                    { ar: `خطوة ${step + 1} من ${TOTAL_STEPS}`, en: `Step ${step + 1} of ${TOTAL_STEPS}` }
                  )
                : t({ ar: "راجع طلبك قبل فتح واتساب", en: "Review your request before opening WhatsApp" })}
            </DialogDescription>
          </DialogHeader>
          <Progress
            value={((step + 1) / 5) * 100}
            className="mt-3 h-1.5 rounded-none bg-muted"
            aria-label={t({ ar: "تقدم النموذج", en: "Form progress" })}
          />
        </div>

        <div className="px-5 pb-5 pt-5 sm:px-6">
          {/* ------------------------------ STEP 0: domain ------------------------------ */}
          {step === 0 && (
            <div role="radiogroup" aria-label={t({ ar: "مجال النشاط", en: "Business field" })} className="grid grid-cols-2 gap-3 sm:grid-cols-3">
              {DOMAINS.map((d) => {
                const Icon = d.icon;
                const selected = state.domain === d.id;
                return (
                  <button
                    key={d.id}
                    role="radio"
                    aria-checked={selected}
                    onClick={() => set("domain", d.id)}
                    className={cn(
                      "group relative flex flex-col items-start gap-2.5 border p-4 text-start transition-all",
                      selected
                        ? "border-brand bg-accent shadow-[3px_3px_0_0_var(--brand)]"
                        : "border-border bg-card hover:border-brand/60"
                    )}
                  >
                    <Icon className={cn("h-6 w-6", selected ? "text-brand" : "text-muted-foreground")} aria-hidden="true" />
                    <span className="text-sm font-semibold leading-snug">
                      {t({ ar: d.ar, en: d.en })}
                    </span>
                    {selected && (
                      <span className="absolute end-2 top-2 flex h-5 w-5 items-center justify-center bg-brand text-brand-foreground">
                        <Check className="h-3.5 w-3.5" aria-hidden="true" />
                      </span>
                    )}
                  </button>
                );
              })}
              {fieldError("domain")}
            </div>
          )}

          {/* ----------------------------- STEP 1: services ----------------------------- */}
          {step === 1 && state.domain && (
            <div>
              <fieldset>
                <legend className="mb-3 text-sm font-medium text-muted-foreground">
                  {t({
                    ar: "اختر خدمة أو أكثر بما يناسب مشروعك:",
                    en: "Choose one or more services that fit your project:",
                  })}
                </legend>
                <div className="flex flex-col gap-2.5">
                  {DOMAINS.find((d) => d.id === state.domain)!.services.map((sid) => {
                    const svc = SERVICES.find((s) => s.id === sid)!;
                    const Icon = svc.icon;
                    const checked = state.services.includes(svc.id);
                    return (
                      <label
                        key={svc.id}
                        className={cn(
                          "flex cursor-pointer items-start gap-3 border p-3.5 transition-colors",
                          checked ? "border-brand bg-accent" : "border-border bg-card hover:border-brand/50"
                        )}
                      >
                        <Checkbox
                          checked={checked}
                          onCheckedChange={(v) =>
                            set(
                              "services",
                              v
                                ? [...state.services, svc.id]
                                : state.services.filter((x) => x !== svc.id)
                            )
                          }
                          className="mt-0.5 rounded-none data-[state=checked]:border-brand data-[state=checked]:bg-brand data-[state=checked]:text-brand-foreground"
                          aria-label={t({ ar: svc.ar, en: svc.en })}
                        />
                        <span className="flex-1">
                          <span className="flex items-center gap-2 text-sm font-semibold">
                            <Icon className="h-4 w-4 text-brand" aria-hidden="true" />
                            {t({ ar: svc.ar, en: svc.en })}
                          </span>
                          <span className="mt-1 block text-xs leading-relaxed text-muted-foreground">
                            {t({ ar: svc.arDesc, en: svc.enDesc })}
                          </span>
                        </span>
                      </label>
                    );
                  })}
                </div>
              </fieldset>

              <label className="mt-4 flex cursor-pointer items-center gap-3 border border-dashed border-brand/50 bg-brand-soft/40 p-3.5">
                <Checkbox
                  checked={state.helpMe}
                  onCheckedChange={(v) => set("helpMe", v === true)}
                  className="rounded-none data-[state=checked]:border-brand data-[state=checked]:bg-brand data-[state=checked]:text-brand-foreground"
                  aria-label={t({ ar: "ساعدوني في الاختيار", en: "Help me choose" })}
                />
                <LifeBuoy className="h-4 w-4 text-brand" aria-hidden="true" />
                <span className="text-sm font-medium">
                  {t({
                    ar: "لا أعرف الخدمة المناسبة — ساعدوني في الاختيار",
                    en: "I'm not sure — help me choose",
                  })}
                </span>
              </label>
              {fieldError("services")}
            </div>
          )}

          {/* ----------------------------- STEP 2: details ----------------------------- */}
          {step === 2 && (
            <div className="grid gap-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <Label htmlFor="rf-name" className="text-sm font-semibold">
                    {t({ ar: "الاسم", en: "Your name" })} <span className="text-brand">*</span>
                  </Label>
                  <Input
                    id="rf-name"
                    value={state.name}
                    onChange={(e) => set("name", e.target.value)}
                    placeholder={t({ ar: "مثال: محمد سالم", en: "e.g. Mohammed Salem" })}
                    className="mt-1.5 rounded-none"
                    autoComplete="name"
                  />
                  {fieldError("name")}
                </div>
                <div>
                  <Label htmlFor="rf-business" className="text-sm font-semibold">
                    {t({ ar: "اسم النشاط أو الشركة", en: "Business name" })} <span className="text-brand">*</span>
                  </Label>
                  <Input
                    id="rf-business"
                    value={state.business}
                    onChange={(e) => set("business", e.target.value)}
                    placeholder={t({ ar: "مثال: مشويات الأصيل", en: "e.g. Asil Grill" })}
                    className="mt-1.5 rounded-none"
                    autoComplete="organization"
                  />
                  {fieldError("business")}
                </div>
              </div>
              <div>
                <Label htmlFor="rf-city" className="text-sm font-semibold">
                  {t({ ar: "المدينة / البلد", en: "City / country" })} <span className="text-brand">*</span>
                </Label>
                <Input
                  id="rf-city"
                  value={state.city}
                  onChange={(e) => set("city", e.target.value)}
                  placeholder={t({ ar: "مثال: صنعاء، اليمن", en: "e.g. Sana'a, Yemen" })}
                  className="mt-1.5 rounded-none"
                />
                {fieldError("city")}
              </div>
              <div>
                <Label htmlFor="rf-desc" className="text-sm font-semibold">
                  {t({ ar: "وصف مختصر لفكرتك أو احتياجك", en: "Short description of your idea" })}{" "}
                  <span className="text-brand">*</span>
                </Label>
                <Textarea
                  id="rf-desc"
                  value={state.description}
                  onChange={(e) => set("description", e.target.value)}
                  placeholder={t({
                    ar: "ما الذي تريد أن يفعله الموقع لمشروعك؟ ما الخدمات أو المنتجات التي سيعرضها؟",
                    en: "What should the website do for your project? What services or products will it present?",
                  })}
                  rows={4}
                  className="mt-1.5 rounded-none"
                />
                {fieldError("description")}
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <Label htmlFor="rf-site" className="text-sm font-semibold">
                    {t({ ar: "رابط موقع حالي (اختياري)", en: "Current website (optional)" })}
                  </Label>
                  <Input
                    id="rf-site"
                    value={state.currentSite}
                    onChange={(e) => set("currentSite", e.target.value)}
                    placeholder="example.com"
                    dir="ltr"
                    className="mt-1.5 rounded-none text-start"
                    type="url"
                  />
                </div>
                <div>
                  <Label htmlFor="rf-time" className="text-sm font-semibold">
                    {t({ ar: "أفضل وقت للتواصل (اختياري)", en: "Best time to reach you (optional)" })}
                  </Label>
                  <Input
                    id="rf-time"
                    value={state.preferredTime}
                    onChange={(e) => set("preferredTime", e.target.value)}
                    placeholder={t({ ar: "مثال: صباحًا بعد العاشرة", en: "e.g. mornings after 10" })}
                    className="mt-1.5 rounded-none"
                  />
                </div>
              </div>
            </div>
          )}

          {/* ---------------------------- STEP 3: contact ---------------------------- */}
          {step === 3 && (
            <div>
              <p className="mb-4 text-sm text-muted-foreground">
                {t({
                  ar: "اختر الشخص الذي سيفتح معه المحادثة. لن تُرسل بياناتك لأحد قبل أن تختار وتضغط إرسال بنفسك.",
                  en: "Choose who will receive your message. Nothing is sent until you pick and press send yourself.",
                })}
              </p>
              <div role="radiogroup" aria-label={t({ ar: "جهة التواصل", en: "Contact person" })} className="grid gap-3 sm:grid-cols-2">
                {(["hasan", "alawi"] as ContactId[]).map((id) => {
                  const p = CONTACTS[id];
                  const selected = state.target === id;
                  return (
                    <button
                      key={id}
                      role="radio"
                      aria-checked={selected}
                      onClick={() => set("target", id)}
                      className={cn(
                        "relative flex items-start gap-3.5 border p-4 text-start transition-all",
                        selected
                          ? "border-brand bg-accent shadow-[3px_3px_0_0_var(--brand)]"
                          : "border-border bg-card hover:border-brand/60"
                      )}
                    >
                      {p.photo ? (
                        <span className="relative block h-14 w-14 shrink-0 overflow-hidden bg-cream">
                          <Image src={p.photo} alt={t({ ar: p.ar, en: p.en })} fill sizes="56px" className="object-cover" />
                        </span>
                      ) : (
                        <span className="flex h-14 w-14 shrink-0 items-center justify-center bg-deep text-xl font-bold text-deep-foreground">
                          {p.initials}
                        </span>
                      )}
                      <span className="min-w-0 flex-1">
                        <span className="block font-bold">{t({ ar: p.ar, en: p.en })}</span>
                        <span className="mt-0.5 block text-xs text-muted-foreground">
                          {t({ ar: p.roleAr, en: p.roleEn })}
                        </span>
                        <span className="mt-1.5 block text-xs font-medium text-brand" dir="ltr">
                          {p.phoneDisplay}
                        </span>
                      </span>
                      {selected && (
                        <span className="absolute end-2 top-2 flex h-5 w-5 items-center justify-center bg-brand text-brand-foreground">
                          <Check className="h-3.5 w-3.5" aria-hidden="true" />
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
              {fieldError("target")}
            </div>
          )}

          {/* ---------------------------- STEP 4: review ---------------------------- */}
          {step === 4 && target && (
            <div>
              <dl className="flex flex-col divide-y divide-border border border-border bg-card">
                <Row label={t({ ar: "الاسم", en: "Name" })} value={state.name} editStep={2} onEdit={setStep} />
                <Row label={t({ ar: "النشاط", en: "Business" })} value={state.business} editStep={2} onEdit={setStep} />
                <Row label={t({ ar: "المدينة / البلد", en: "City / country" })} value={state.city} editStep={2} onEdit={setStep} />
                <Row label={t({ ar: "مجال النشاط", en: "Field" })} value={domainLabel} editStep={0} onEdit={setStep} />
                <Row
                  label={t({ ar: "الخدمات", en: "Services" })}
                  value={servicesLabel || t({ ar: "مساعدة في الاختيار", en: "Help me choose" })}
                  editStep={1}
                  onEdit={setStep}
                />
                <Row label={t({ ar: "تفاصيل المشروع", en: "Project details" })} value={state.description} editStep={2} onEdit={setStep} />
                {state.currentSite.trim() && (
                  <Row label={t({ ar: "الموقع الحالي", en: "Current website" })} value={state.currentSite} editStep={2} onEdit={setStep} ltr />
                )}
                {state.preferredTime.trim() && (
                  <Row label={t({ ar: "أفضل وقت للتواصل", en: "Best time to contact" })} value={state.preferredTime} editStep={2} onEdit={setStep} />
                )}
                <Row label={t({ ar: "جهة التواصل", en: "Contact" })} value={t({ ar: target.ar, en: target.en })} editStep={3} onEdit={setStep} />
              </dl>

              <div className="mt-4 border border-dashed border-brand/50 bg-brand-soft/40 p-4 text-sm leading-relaxed text-foreground/90">
                <p className="font-semibold text-foreground">
                  {t({ ar: "كيف يتم الإرسال؟", en: "How sending works" })}
                </p>
                <p className="mt-1 text-muted-foreground">
                  {t({
                    ar: "عند الضغط على الزر سيُفتح واتساب برسالة مُعبّأة بمعلوماتك. تبقى حرية تعديل الرسالة أو حذف أي معلومة لك قبل أن تضغط إرسال داخل واتساب.",
                    en: "Pressing the button opens WhatsApp with your details pre-filled. You stay free to edit or remove anything before pressing send inside WhatsApp.",
                  })}
                </p>
              </div>
            </div>
          )}
        </div>

        {/* ------------------------------ footer buttons ------------------------------ */}
        <div className="sticky bottom-0 z-10 flex items-center justify-between gap-3 border-t border-border bg-background/95 px-5 py-4 backdrop-blur sm:px-6">
          {step > 0 ? (
            <Button variant="ghost" onClick={back} className="rounded-none">
              <BackArrow className="h-4 w-4" aria-hidden="true" />
              {t({ ar: "رجوع", en: "Back" })}
            </Button>
          ) : (
            <span />
          )}

          {step < 4 ? (
            <Button onClick={next} className="rounded-none font-semibold">
              {t({ ar: "التالي", en: "Next" })}
              <FwdChevron className="h-4 w-4" aria-hidden="true" />
            </Button>
          ) : (
            <Button onClick={submit} disabled={sending} className="rounded-none bg-brand font-semibold text-brand-foreground hover:bg-brand/90">
              <WhatsAppIcon className="h-4 w-4" aria-hidden="true" />
              {t({ ar: "فتح واتساب وإرسال الملخص", en: "Open WhatsApp & send summary" })}
            </Button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

/* ------------------------------------------------------------------ */
/* Review row                                                          */
/* ------------------------------------------------------------------ */

function Row({
  label,
  value,
  editStep,
  onEdit,
  ltr,
}: {
  label: string;
  value: string;
  editStep: number;
  onEdit: (s: number) => void;
  ltr?: boolean;
}) {
  const { t } = useLang();
  return (
    <div className="flex items-start justify-between gap-3 px-4 py-3">
      <div className="min-w-0">
        <dt className="text-xs font-medium text-muted-foreground">{label}</dt>
        <dd
          className={cn("mt-0.5 whitespace-pre-wrap break-words text-sm font-medium", ltr && "text-start")}
          dir={ltr ? "ltr" : undefined}
        >
          {value}
        </dd>
      </div>
      <button
        onClick={() => onEdit(editStep)}
        className="shrink-0 text-xs font-semibold text-brand underline-offset-4 hover:underline"
      >
        {t({ ar: "تعديل", en: "Edit" })}
      </button>
    </div>
  );
}

// Re-export so other components can trigger the form without importing shared twice.
export { openRequest };
