"use client";

import { motion, useReducedMotion } from "framer-motion";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { useLang } from "@/lib/lang";
import { Container, Section, SectionHeading } from "./shared";

/* ------------------------------------------------------------------ */
/* FAQ — honest answers paraphrasing the approved plan                 */
/* ------------------------------------------------------------------ */

const FAQS: Array<{ q: { ar: string; en: string }; a: { ar: string; en: string } }> = [
  {
    q: { ar: "كم يستغرق بناء الموقع؟", en: "How long does building a website take?" },
    a: {
      ar: "يختلف حسب نوع الموقع وحجم المحتوى، ونحدد الإطار الزمني معك في البداية ضمن نطاق متفق عليه.",
      en: "It depends on the type of website and the amount of content. We agree on the timeline with you at the start, within an agreed scope.",
    },
  },
  {
    q: { ar: "ما الذي أحتاج تجهيزه قبل البدء؟", en: "What do I need to prepare before starting?" },
    a: {
      ar: "شعار النشاط إن وجد، المحتوى الأساسي (الخدمات أو المنتجات)، الصور، ومعلومات التواصل — وننسق معك الباقي خطوة بخطوة.",
      en: "Your logo (if you have one), the core content (your services or products), images, and contact details — we coordinate the rest with you step by step.",
    },
  },
  {
    q: {
      ar: "لا أعرف أي خدمة تناسبني، ماذا أفعل؟",
      en: "I don't know which service suits me — what should I do?",
    },
    a: {
      ar: "اختر «ساعدوني في الاختيار» في نموذج الطلب وسنقترح الأنسب دون أي التزام.",
      en: "Choose “Help me choose” in the request form and we'll suggest the best fit, with no commitment.",
    },
  },
  {
    q: { ar: "هل تطوّرون موقعًا قائمًا بالفعل؟", en: "Do you improve an existing website?" },
    a: {
      ar: "نعم، نراجع احتياج الموقع الحالي ونطوّر الأجزاء المتفق عليها لتحسين وضوحه أو وظائفه.",
      en: "Yes. We review the current website's needs and develop the agreed parts to improve its clarity or functionality.",
    },
  },
  {
    q: { ar: "كيف يتم التواصل أثناء العمل؟", en: "How do we communicate during the work?" },
    a: {
      ar: "عبر واتساب مع الشخص الذي تختاره من الفريق، بخطوات متفق عليها من البداية حتى التسليم.",
      en: "Via WhatsApp with the team member you choose, following agreed steps from the start until delivery.",
    },
  },
  {
    q: {
      ar: "هل توفرون صيانة واستضافة بعد التسليم؟",
      en: "Do you provide maintenance and hosting after delivery?",
    },
    a: {
      ar: "نوفّر خيارات دعم وصيانة واستضافة تُحدّد تفاصيلها ومدتها ضمن اتفاق واضح للمشروع.",
      en: "Yes — support, maintenance, and hosting options whose details and duration are defined in a clear project agreement.",
    },
  },
];

/* ------------------------------------------------------------------ */
/* Component                                                           */
/* ------------------------------------------------------------------ */

export function FaqSection() {
  const { t } = useLang();
  const reduce = useReducedMotion();

  const fade = (delay: number) =>
    reduce
      ? {}
      : {
          initial: { opacity: 0, y: 18 },
          whileInView: { opacity: 1, y: 0 },
          viewport: { once: true, margin: "-60px" },
          transition: { duration: 0.55, delay, ease: [0.22, 1, 0.36, 1] as const },
        };

  return (
    <Section id="faq" ariaLabel={t({ ar: "أسئلة شائعة", en: "Frequently asked questions" })}>
      <Container>
        <motion.div {...fade(0)}>
          <SectionHeading
            eyebrow={t({ ar: "أسئلة شائعة", en: "FAQ" })}
            title={t({ ar: "إجابات قصيرة قبل أن تبدأ", en: "Short answers before you start" })}
          />
        </motion.div>

        <motion.div {...fade(0.1)} className="max-w-3xl">
          <Accordion type="single" collapsible className="w-full">
            {FAQS.map((f, i) => (
              <AccordionItem
                key={f.q.ar}
                value={`faq-${i}`}
                className="mb-3 rounded-none border border-border bg-card px-4 last:border-b sm:px-5"
              >
                <AccordionTrigger className="rounded-none py-5 text-start hover:no-underline">
                  <span className="flex items-start gap-3 text-start">
                    <span
                      dir="ltr"
                      aria-hidden="true"
                      className="mt-1 font-mono text-xs font-bold text-brand"
                    >
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    <span className="text-base font-semibold">{t({ ar: f.q.ar, en: f.q.en })}</span>
                  </span>
                </AccordionTrigger>
                <AccordionContent className="ps-6 text-base leading-relaxed text-muted-foreground sm:ps-8">
                  {t({ ar: f.a.ar, en: f.a.en })}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </motion.div>
      </Container>
    </Section>
  );
}
