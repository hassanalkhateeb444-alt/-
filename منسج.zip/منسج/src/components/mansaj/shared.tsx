"use client";

import { useEffect, useRef, useState } from "react";
import { useInView, useReducedMotion } from "framer-motion";
import { cn } from "@/lib/utils";

/* ------------------------------------------------------------------ */
/* Layout primitives                                                   */
/* ------------------------------------------------------------------ */

export function Container({
  className,
  children,
}: {
  className?: string;
  children: React.ReactNode;
}) {
  /* Extra inline-start padding below xl keeps content clear of the
     floating nav dock that hovers over the start edge (right in RTL). */
  return (
    <div
      className={cn(
        "mx-auto w-full max-w-6xl pe-4 ps-[64px] sm:pe-6 sm:ps-[68px] xl:ps-6",
        className
      )}
    >
      {children}
    </div>
  );
}

export function Section({
  id,
  className,
  children,
  ariaLabel,
}: {
  id?: string;
  className?: string;
  children: React.ReactNode;
  ariaLabel?: string;
}) {
  return (
    <section
      id={id}
      aria-label={ariaLabel}
      className={cn("relative scroll-mt-20 py-16 sm:py-20 lg:py-24", className)}
    >
      {children}
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* Brand marks                                                         */
/* ------------------------------------------------------------------ */

/**
 * Mosaic "M" mark — rectangular cells echoing the Mansaj logo.
 * One turquoise accent cell, like the original mark.
 */
export function MosaicMark({
  className,
  accentClassName,
}: {
  className?: string;
  accentClassName?: string;
}) {
  const cells: Array<[number, number]> = [
    // left column
    [0, 0], [0, 1], [0, 2], [0, 3],
    // right column
    [4, 0], [4, 1], [4, 2], [4, 3],
    // diagonals toward the middle
    [1, 0], [1, 1],
    [3, 0], [3, 1],
    [2, 1], [2, 2],
  ];
  return (
    <svg
      viewBox="0 0 5 4"
      aria-hidden="true"
      className={cn("h-5 w-6", className)}
      shapeRendering="crispEdges"
    >
      {cells.map(([x, y]) => (
        <rect key={`${x}-${y}`} x={x} y={y} width="0.92" height="0.92" fill="currentColor" />
      ))}
      <rect x="2" y="2" width="0.92" height="0.92" className={cn("fill-brand", accentClassName)} />
    </svg>
  );
}

/** Small squares strip used as an eyebrow/section marker. */
export function SquaresStrip({ className }: { className?: string }) {
  return (
    <span aria-hidden="true" className={cn("inline-flex items-center gap-1", className)}>
      <span className="h-2 w-2 bg-brand" />
      <span className="h-2 w-2 bg-brand/45" />
      <span className="h-2 w-2 bg-foreground/25" />
    </span>
  );
}

/* ------------------------------------------------------------------ */
/* Section heading                                                     */
/* ------------------------------------------------------------------ */

export function SectionHeading({
  eyebrow,
  title,
  description,
  align = "start",
  className,
}: {
  eyebrow?: string;
  title: string;
  description?: string;
  align?: "start" | "center";
  className?: string;
}) {
  return (
    <div
      className={cn(
        "mb-10 max-w-2xl sm:mb-12",
        align === "center" && "mx-auto text-center",
        className
      )}
    >
      {eyebrow ? (
        <p
          className={cn(
            "mb-3 flex items-center gap-2.5 text-sm font-semibold text-brand",
            align === "center" && "justify-center"
          )}
        >
          <SquaresStrip />
          {eyebrow}
        </p>
      ) : null}
      <h2 className="text-3xl font-bold leading-[1.25] tracking-tight sm:text-4xl">
        {title}
      </h2>
      {description ? (
        <p className="mt-4 text-base leading-relaxed text-muted-foreground sm:text-lg">
          {description}
        </p>
      ) : null}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Count-up number                                                     */
/* ------------------------------------------------------------------ */

export function CountUp({
  to,
  prefix,
  suffix,
  duration = 1.6,
  className,
}: {
  to: number;
  prefix?: string;
  suffix?: string;
  duration?: number;
  className?: string;
}) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: "-40px" });
  const reduce = useReducedMotion();
  const [val, setVal] = useState(0);

  useEffect(() => {
    if (!inView || reduce) return;
    let raf = 0;
    const start = performance.now();
    const tick = (now: number) => {
      const p = Math.min(1, (now - start) / (duration * 1000));
      const eased = 1 - Math.pow(1 - p, 3);
      setVal(Math.round(to * eased));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [inView, to, duration, reduce]);

  const display = reduce ? to : val;

  return (
    <span ref={ref} className={className} dir="ltr">
      {prefix}
      {display.toLocaleString("en-US")}
      {suffix}
    </span>
  );
}

/* ------------------------------------------------------------------ */
/* Icons                                                               */
/* ------------------------------------------------------------------ */

export function WhatsAppIcon({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="currentColor"
      aria-hidden="true"
      className={cn("h-4 w-4", className)}
    >
      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z" />
    </svg>
  );
}

/* ------------------------------------------------------------------ */
/* Cross-component request trigger                                     */
/* ------------------------------------------------------------------ */

export interface RequestDetail {
  serviceId?: string;
  domain?: string;
}

/**
 * Open the project request form from anywhere.
 * The <RequestForm> listens for this event.
 */
export function openRequest(detail?: RequestDetail) {
  if (typeof window === "undefined") return;
  window.dispatchEvent(
    new CustomEvent<RequestDetail>("mansaj:start-request", { detail: detail ?? {} })
  );
}

/** Smooth-scroll to a section id (CSS handles reduced-motion). */
export function scrollToSection(id: string) {
  if (typeof window === "undefined") return;
  document.getElementById(id)?.scrollIntoView();
}
