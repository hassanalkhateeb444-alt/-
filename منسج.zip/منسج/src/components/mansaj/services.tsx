"use client";

import { motion, useReducedMotion } from "framer-motion";
import { ArrowLeft, ArrowRight } from "lucide-react";
import { useLang } from "@/lib/lang";
import { Button } from "@/components/ui/button";
import { Container, Section, SectionHeading, openRequest } from "./shared";
import { SERVICES } from "./data";

export function ServicesSection() {
  const { t, dir } = useLang();
  const reduce = useReducedMotion();
  const Arrow = dir === "rtl" ? ArrowLeft : ArrowRight;

  const fade = (delay: number) =>
    reduce
      ? {}
      : {
          initial: { opacity: 0, y: 18 },
          whileInView: { opacity: 1, y: 0 },
          viewport: { once: true, margin: "-60px" },
          transition: { duration: 0.55, delay, ease: [0.22, 1, 0.36, 1] as const },
        };

  return (
    <Section
      id="services"
      ariaLabel={t({ ar: "خدمات منسج", en: "Mansaj services" })}
    >
      <Container>
        <SectionHeading
          eyebrow={t({ ar: "الخدمات", en: "Services" })}
          title={t({
            ar: "اختر ما يحتاجه مشروعك، لا ما يبدو رائجًا فقط.",
            en: "Choose what your project needs, not just what looks trendy.",
          })}
          description={t({
            ar: "لكل نشاط احتياجات مختلفة. استكشف الخدمات، ثم أخبرنا عن مشروعك لنساعدك في تحديد نقطة البداية.",
            en: "Every business has different needs. Explore the services, then tell us about your project so we can help you find the right starting point.",
          })}
        />

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 lg:gap-5">
          {SERVICES.map((svc, i) => {
            const Icon = svc.icon;
            return (
              <motion.article
                key={svc.id}
                {...fade((i % 3) * 0.08)}
                className="group flex flex-col border border-border bg-card p-5 transition-all hover:border-brand hover:shadow-[4px_4px_0_0_var(--brand)] focus-within:border-brand focus-within:shadow-[4px_4px_0_0_var(--brand)]"
              >
                <div className="flex items-start gap-3.5">
                  {/* squared icon container — never rounded */}
                  <span className="flex h-11 w-11 shrink-0 items-center justify-center bg-brand-soft text-foreground">
                    <Icon className="h-5 w-5" aria-hidden="true" />
                  </span>
                  <h3 className="min-h-12 pt-0.5 text-base font-bold leading-snug">
                    {t({ ar: svc.ar, en: svc.en })}
                  </h3>
                </div>

                <p className="mb-5 mt-3 line-clamp-3 text-sm leading-relaxed text-muted-foreground">
                  {t({ ar: svc.arDesc, en: svc.enDesc })}
                </p>

                <div className="mt-auto">
                  <Button
                    variant="outline"
                    onClick={() => openRequest({ serviceId: svc.id })}
                    className="h-11 w-full justify-between rounded-none bg-transparent px-4 text-sm font-semibold text-foreground hover:border-brand hover:bg-brand-soft hover:text-foreground dark:border-border dark:bg-transparent dark:hover:border-brand dark:hover:bg-brand-soft dark:hover:text-foreground"
                  >
                    {t({ ar: "أريد هذه الخدمة", en: "I want this service" })}
                    <Arrow
                      className="h-4 w-4 transition-transform rtl:group-hover:-translate-x-1 ltr:group-hover:translate-x-1"
                      aria-hidden="true"
                    />
                  </Button>
                </div>
              </motion.article>
            );
          })}
        </div>
      </Container>
    </Section>
  );
}
