"use client";

import { motion, useReducedMotion } from "framer-motion";
import { ArrowLeft, ArrowRight, Instagram } from "lucide-react";
import Image from "next/image";
import { Button } from "@/components/ui/button";
import { useLang } from "@/lib/lang";
import { cn } from "@/lib/utils";
import { BRAND, CONTACTS, type ContactId } from "./data";
import { Container, MosaicMark, Section, WhatsAppIcon, openRequest } from "./shared";

/* ------------------------------------------------------------------ */
/* Component                                                           */
/* ------------------------------------------------------------------ */

const CONTACT_ORDER: ContactId[] = ["hasan", "alawi"];

export function ContactSection() {
  const { t, dir } = useLang();
  const reduce = useReducedMotion();
  const Arrow = dir === "rtl" ? ArrowLeft : ArrowRight;

  const fade = (delay: number) =>
    reduce
      ? {}
      : {
          initial: { opacity: 0, y: 18 },
          whileInView: { opacity: 1, y: 0 },
          viewport: { once: true, margin: "-60px" },
          transition: { duration: 0.55, delay, ease: [0.22, 1, 0.36, 1] as const },
        };

  return (
    <Section id="contact" ariaLabel={t({ ar: "تواصل مع منسج", en: "Contact Mansaj" })}>
      <Container>
        {/* Final CTA panel */}
        <motion.div
          {...fade(0)}
          className="relative overflow-hidden border border-brand/30 bg-deep p-6 text-deep-foreground sm:p-10 lg:p-12"
        >
          <div aria-hidden="true" className="absolute inset-0 bg-blueprint opacity-25" />
          <MosaicMark className="pointer-events-none absolute -top-2 end-6 hidden h-14 w-18 text-cream/20 sm:block" />
          <div
            aria-hidden="true"
            className="pointer-events-none absolute bottom-7 start-8 hidden grid-cols-3 gap-1.5 lg:grid"
          >
            {Array.from({ length: 9 }).map((_, i) => (
              <span
                key={i}
                className={cn("h-3 w-3", i % 4 === 0 ? "bg-brand/40" : "bg-deep-foreground/15")}
              />
            ))}
          </div>

          <div className="relative">
            <h2 className="max-w-2xl text-3xl font-bold leading-[1.25] tracking-tight sm:text-4xl">
              {t({ ar: "جاهز تطوّر حضور مشروعك؟", en: "Ready to develop your project's presence?" })}
            </h2>
            <p className="mt-4 max-w-2xl text-base leading-relaxed text-deep-foreground/85 sm:text-lg">
              {t({
                ar: "اختر نوع الخدمة، وأخبرنا ببعض التفاصيل، وسنجهز لك رسالة واضحة لتبدأ المحادثة مع الشخص المناسب من فريق منسج.",
                en: "Pick your service type, tell us a few details, and we'll prepare a clear message to start the conversation with the right person from the Mansaj team.",
              })}
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:items-center">
              <Button
                onClick={() => openRequest()}
                className="h-12 rounded-sm bg-brand px-7 text-base font-semibold text-brand-foreground hover:bg-brand/90"
              >
                {t({ ar: "ابدأ باختيار الخدمة", en: "Start by choosing a service" })}
              </Button>
            </div>
            <p className="mt-5 text-sm text-deep-foreground/75">
              {t({
                ar: "لا تعرف أي خدمة تناسبك؟ اختر «ساعدوني في الاختيار» في النموذج.",
                en: "Not sure which service fits? Choose “Help me choose” in the form.",
              })}
            </p>
          </div>
        </motion.div>

        {/* Contact cards: Hasan / Alawi / Instagram */}
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {CONTACT_ORDER.map((id, i) => {
            const c = CONTACTS[id];
            const isHasan = id === "hasan";
            return (
              <motion.article
                key={id}
                {...fade(0.1 + i * 0.08)}
                className="flex flex-col border border-border bg-card p-5 transition-all hover:border-brand hover:shadow-[4px_4px_0_0_var(--brand)] sm:p-6"
              >
                <div className="flex items-center gap-3.5">
                  {isHasan && c.photo ? (
                    <span className="relative block h-12 w-12 shrink-0 overflow-hidden rounded-sm border border-border">
                      <Image
                        src={c.photo}
                        alt={t({ ar: c.ar, en: c.en })}
                        fill
                        sizes="48px"
                        className="object-cover"
                      />
                    </span>
                  ) : (
                    <span
                      aria-hidden="true"
                      className="flex h-12 w-12 shrink-0 items-center justify-center rounded-sm bg-deep text-lg font-bold text-deep-foreground"
                    >
                      {t({ ar: "ع", en: "A" })}
                    </span>
                  )}
                  <div>
                    <h3 className="text-base font-bold">{t({ ar: c.ar, en: c.en })}</h3>
                    <p className="mt-0.5 text-sm font-semibold text-brand">
                      {t({ ar: c.roleAr, en: c.roleEn })}
                    </p>
                  </div>
                </div>

                <p className="mt-5 flex items-center gap-2 text-xs font-semibold text-muted-foreground">
                  <span aria-hidden="true" className="h-1.5 w-1.5 bg-brand" />
                  {t({ ar: "واتساب", en: "WhatsApp" })}
                </p>
                <p dir="ltr" className="mt-1 font-mono text-lg font-semibold tracking-wide">
                  {c.phoneDisplay}
                </p>

                <div className="mt-auto pt-5">
                  <Button asChild variant="outline" className="h-11 w-full rounded-sm font-semibold">
                    <a href={`https://wa.me/${c.wa}`} target="_blank" rel="noopener noreferrer">
                      <WhatsAppIcon className="h-4 w-4 text-brand" />
                      {t({ ar: "محادثة واتساب مباشرة", en: "Direct WhatsApp chat" })}
                    </a>
                  </Button>
                </div>
              </motion.article>
            );
          })}

          {/* Instagram — the brand's official account */}
          <motion.a
            {...fade(0.26)}
            href={BRAND.instagram}
            target="_blank"
            rel="noopener noreferrer"
            className="group flex flex-col border border-border bg-card p-5 transition-all hover:border-brand hover:shadow-[4px_4px_0_0_var(--brand)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring sm:p-6"
          >
            <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-sm bg-brand text-brand-foreground">
              <Instagram className="h-5 w-5" aria-hidden="true" />
            </span>
            <span dir="ltr" className="mt-4 block font-mono text-lg font-bold">
              {BRAND.instagramHandle}
            </span>
            <span className="mt-2 block text-sm leading-relaxed text-muted-foreground">
              {t({
                ar: "حساب منسج الرقمية الرسمي على إنستغرام — تابع أعمالنا الجديدة",
                en: "The official Mansaj Digital Instagram — follow our latest work",
              })}
            </span>
            <span className="mt-auto inline-flex items-center gap-1.5 pt-4 text-sm font-semibold text-brand">
              {t({ ar: "فتح إنستغرام", en: "Open Instagram" })}
              <Arrow
                aria-hidden="true"
                className="h-4 w-4 rtl:group-hover:-translate-x-1 ltr:group-hover:translate-x-1"
              />
            </span>
          </motion.a>
        </div>
      </Container>
    </Section>
  );
}
