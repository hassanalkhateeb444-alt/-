"use client";

import { motion, useReducedMotion } from "framer-motion";
import Image from "next/image";
import { ArrowLeft, ArrowRight, Compass, PenSquare } from "lucide-react";
import { useLang } from "@/lib/lang";
import { Container, MosaicMark, openRequest, scrollToSection } from "./shared";

export function Hero() {
  const { t, dir } = useLang();
  const reduce = useReducedMotion();
  const Arrow = dir === "rtl" ? ArrowLeft : ArrowRight;

  const fade = (delay: number) =>
    reduce
      ? {}
      : {
          initial: { opacity: 0, y: 18 },
          animate: { opacity: 1, y: 0 },
          transition: { duration: 0.55, delay, ease: [0.22, 1, 0.36, 1] as const },
        };

  return (
    <section id="home" aria-label={t({ ar: "الواجهة الرئيسية", en: "Hero" })} className="relative overflow-hidden pt-16">
      {/* Blueprint grid backdrop */}
      <div aria-hidden="true" className="bg-blueprint absolute inset-0" />
      {/* Geometric corner accents */}
      <div aria-hidden="true" className="pointer-events-none absolute -top-3 end-6 hidden lg:block">
        <MosaicMark className="h-16 w-20 text-brand/25" />
      </div>
      <div aria-hidden="true" className="pointer-events-none absolute bottom-10 start-4 hidden lg:block">
        <div className="grid grid-cols-3 gap-1.5">
          {Array.from({ length: 9 }).map((_, i) => (
            <span
              key={i}
              className={`h-3 w-3 ${i % 4 === 0 ? "bg-brand/30" : "bg-foreground/10"}`}
            />
          ))}
        </div>
      </div>

      <Container className="relative pb-14 pt-10 sm:pb-20 sm:pt-14 lg:pt-20">
        <motion.div {...fade(0)} className="mx-auto max-w-3xl text-center">
          <span className="inline-flex items-center gap-2 border border-border bg-card px-3.5 py-1.5 text-xs font-semibold text-muted-foreground sm:text-sm">
            <MosaicMark className="h-3 w-4 text-brand" />
            {t({ ar: "منسج الرقمية · نبني حضورك على الويب", en: "Mansaj Digital · We build your web presence" })}
          </span>

          <h1 className="mt-6 text-4xl font-bold leading-[1.2] tracking-tight sm:text-5xl lg:text-6xl">
            {t({
              ar: "مشروعك يستحق موقعًا يعمل لأجله.",
              en: "Your project deserves a website that works for it.",
            })}
          </h1>
          <p className="mx-auto mt-5 max-w-2xl text-base leading-relaxed text-muted-foreground sm:text-lg">
            {t({
              ar: "نصمّم ونطوّر مواقع ومتاجر وتجارب رقمية تساعد عملاءك على فهم ما تقدمه، والوصول إليك، واتخاذ الخطوة التالية بسهولة.",
              en: "We design and build websites, stores, and digital experiences that help your customers understand your offer, reach you, and take the next step easily.",
            })}
          </p>
        </motion.div>

        {/* The guiding question — two clear paths */}
        <motion.div {...fade(0.15)} className="mx-auto mt-10 max-w-3xl sm:mt-12">
          <p className="mb-4 text-center text-sm font-semibold text-foreground/80 sm:text-base">
            {t({ ar: "ما الذي تريد أن تطوّره في مشروعك؟", en: "What do you want to develop in your project?" })}
          </p>
          <div className="grid gap-4 sm:grid-cols-2">
            {/* Path 1 — start a request */}
            <button
              onClick={() => openRequest()}
              className="group relative border border-border bg-card p-5 text-start transition-all hover:border-brand hover:shadow-[4px_4px_0_0_var(--brand)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring sm:p-6"
              aria-label={t({ ar: "أريد موقعًا لمشروعي — ابدأ طلب الخدمة", en: "I want a website — start a request" })}
            >
              <span className="flex h-11 w-11 items-center justify-center bg-primary text-primary-foreground">
                <PenSquare className="h-5 w-5" aria-hidden="true" />
              </span>
              <span className="mt-4 block text-lg font-bold">
                {t({ ar: "أريد موقعًا لمشروعي", en: "I want a website for my project" })}
              </span>
              <span className="mt-1.5 block text-sm leading-relaxed text-muted-foreground">
                {t({
                  ar: "خطوات قصيرة تحدد خدمتك، ثم نجهّز رسالتك الجاهزة للتواصل.",
                  en: "A few quick steps to define your service, then we prepare your message.",
                })}
              </span>
              <span className="mt-4 inline-flex items-center gap-1.5 text-sm font-semibold text-brand">
                {t({ ar: "ابدأ الآن", en: "Start now" })}
                <Arrow className="h-4 w-4 transition-transform group-hover:-translate-x-0.5 rtl:group-hover:-translate-x-1 ltr:group-hover:translate-x-1" aria-hidden="true" />
              </span>
            </button>

            {/* Path 2 — explore work */}
            <button
              onClick={() => scrollToSection("portfolio")}
              className="group relative border border-border bg-card p-5 text-start transition-all hover:border-brand hover:shadow-[-4px_4px_0_0_var(--brand)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring sm:p-6"
              aria-label={t({ ar: "استكشف أعمال منسج — انتقل إلى المعرض", en: "Explore Mansaj work — go to portfolio" })}
            >
              <span className="flex h-11 w-11 items-center justify-center bg-brand text-brand-foreground">
                <Compass className="h-5 w-5" aria-hidden="true" />
              </span>
              <span className="mt-4 block text-lg font-bold">
                {t({ ar: "أستكشف أعمال منسج", en: "Explore Mansaj's work" })}
              </span>
              <span className="mt-1.5 block text-sm leading-relaxed text-muted-foreground">
                {t({
                  ar: "شاهد مشاريع نُفّذت لمجالات مختلفة، وتخيّل ما يناسب مشروعك.",
                  en: "See projects delivered across different fields and imagine yours.",
                })}
              </span>
              <span className="mt-4 inline-flex items-center gap-1.5 text-sm font-semibold text-brand">
                {t({ ar: "تصفّح الأعمال", en: "Browse work" })}
                <Arrow className="h-4 w-4 rtl:group-hover:-translate-x-1 ltr:group-hover:translate-x-1" aria-hidden="true" />
              </span>
            </button>
          </div>

          <p className="mt-5 text-center">
            <button
              onClick={() => scrollToSection("contact")}
              className="text-sm font-medium text-muted-foreground underline decoration-border underline-offset-4 transition-colors hover:text-brand hover:decoration-brand"
            >
              {t({ ar: "أفضّل التواصل مباشرة", en: "I prefer to get in touch directly" })}
            </button>
          </p>
        </motion.div>

        {/* Showcase — expressive imagery framed in the Mansaj style */}
        <motion.div {...fade(0.22)} className="mx-auto mt-12 max-w-4xl sm:mt-14">
          <div className="grid gap-4">
            {/* Main visual */}
            <figure className="group relative aspect-[16/10] overflow-hidden border border-border bg-card shadow-[6px_6px_0_0_var(--brand-soft)] transition-shadow hover:shadow-[6px_6px_0_0_var(--brand)] sm:aspect-[16/6.6]">
              <Image
                src="/images/show-workspace.jpg"
                alt={t({
                  ar: "مساحة عمل تصميم مواقع فيها شاشات تعرض نماذج مواقع حديثة",
                  en: "Web design workspace with screens showing modern website mockups",
                })}
                fill
                sizes="(max-width: 896px) 100vw, 896px"
                className="object-cover transition-transform duration-500 group-hover:scale-[1.03]"
              />
              <figcaption className="absolute inset-x-0 bottom-0 flex items-center justify-between gap-3 bg-deep/85 px-4 py-2.5 text-cream backdrop-blur-sm">
                <span className="text-xs font-semibold sm:text-sm">
                  {t({
                    ar: "تصميم يظهر بأفضل شكل على كل الشاشات",
                    en: "Design that shines on every screen",
                  })}
                </span>
                <MosaicMark className="hidden h-4 w-5 shrink-0 text-brand sm:block" />
              </figcaption>
            </figure>

            {/* Two supporting visuals */}
            <div className="grid grid-cols-2 gap-4">
              <figure className="group relative aspect-[16/10] overflow-hidden border border-border bg-card shadow-[6px_6px_0_0_var(--brand-soft)] transition-shadow hover:shadow-[6px_6px_0_0_var(--brand)] sm:aspect-[16/6.6]">
                <Image
                  src="/images/show-atelier.jpg"
                  alt={t({
                    ar: "طاولة تفصيل عليها حاسوب محمول يعرض تصميمًا رقميًا",
                    en: "A tailor's desk with a laptop showing a digital design",
                  })}
                  fill
                  sizes="(max-width: 896px) 50vw, 440px"
                  className="object-cover transition-transform duration-500 group-hover:scale-[1.03]"
                />
                <figcaption className="absolute inset-x-0 bottom-0 bg-deep/85 px-3 py-2 text-[11px] font-semibold text-cream backdrop-blur-sm sm:text-xs">
                  {t({ ar: "تفصيل يبدأ من طبيعة نشاطك", en: "Tailored to how your business works" })}
                </figcaption>
              </figure>
              <figure className="group relative aspect-[16/10] overflow-hidden border border-border bg-card shadow-[6px_6px_0_0_var(--brand-soft)] transition-shadow hover:shadow-[6px_6px_0_0_var(--brand)] sm:aspect-[16/6.6]">
                <Image
                  src="/images/show-team.jpg"
                  alt={t({
                    ar: "فريق منسج يعمل معًا حول حاسوب محمول",
                    en: "The Mansaj team working together around a laptop",
                  })}
                  fill
                  sizes="(max-width: 896px) 50vw, 440px"
                  className="object-cover transition-transform duration-500 group-hover:scale-[1.03]"
                />
                <figcaption className="absolute inset-x-0 bottom-0 bg-deep/85 px-3 py-2 text-[11px] font-semibold text-cream backdrop-blur-sm sm:text-xs">
                  {t({ ar: "فريق يرافقك حتى التسليم", en: "A team with you until delivery" })}
                </figcaption>
              </figure>
            </div>
          </div>
        </motion.div>

        {/* Trust line */}
        <motion.div {...fade(0.3)} className="mx-auto mt-12 max-w-3xl sm:mt-16">
          <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-3 border-t border-border pt-6 text-sm text-muted-foreground">
            <span className="flex items-center gap-2">
              <span aria-hidden="true" className="h-1.5 w-1.5 bg-brand" />
              <strong className="font-semibold text-foreground" dir="ltr">+150</strong>
              {t({ ar: "موقع بُني خلال السنة الماضية", en: "websites built last year" })}
            </span>
            <span aria-hidden="true" className="hidden h-4 w-px bg-border sm:block" />
            <span className="flex items-center gap-2">
              <span aria-hidden="true" className="h-1.5 w-1.5 bg-brand" />
              <strong className="font-semibold text-foreground" dir="ltr">150</strong>
              {t({ ar: "عميل", en: "clients" })}
            </span>
            <span aria-hidden="true" className="hidden h-4 w-px bg-border sm:block" />
            <span className="flex items-center gap-2">
              <span aria-hidden="true" className="h-1.5 w-1.5 bg-brand" />
              <strong className="font-semibold text-foreground" dir="ltr">+1</strong>
              {t({ ar: "سنة خبرة", en: "year of experience" })}
            </span>
          </div>
        </motion.div>
      </Container>
    </section>
  );
}
