"use client";

import { useEffect, useRef, useState, useSyncExternalStore } from "react";
import {
  motion,
  useMotionValue,
  useReducedMotion,
  useSpring,
} from "framer-motion";

/* ------------------------------------------------------------------ */
/* Non-traditional cursor — a branded square dot with a trailing       */
/* square frame. Works with mouse/trackpad (desktop) AND touch (mobile) */
/* — the cursor follows the finger and fades after it lifts.           */
/* ------------------------------------------------------------------ */

type CursorVariant = "default" | "link" | "field";

const INTERACTIVE_SELECTOR =
  'a, button, [role="button"], label, summary, select, [data-cursor="link"]';

const FIELD_SELECTOR =
  'input, textarea, [contenteditable="true"], [contenteditable=""]';

const IDLE_HIDE_MS = 1400;

/* Hydration gate without setState-in-effect: false on the server,
   true on the client. */
const emptySubscribe = () => () => {};

export function CustomCursor() {
  const reduce = useReducedMotion();
  const mounted = useSyncExternalStore(
    emptySubscribe,
    () => true,
    () => false
  );
  const active = mounted && !reduce;
  const [visible, setVisible] = useState(false);
  const [variant, setVariant] = useState<CursorVariant>("default");
  const [pressed, setPressed] = useState(false);
  const hideTimer = useRef<number | null>(null);

  const x = useMotionValue(-100);
  const y = useMotionValue(-100);

  /* The dot hugs the pointer almost instantly; the square frame trails
     behind on a softer spring — the signature "non-traditional" lag. */
  const dotX = useSpring(x, { stiffness: 950, damping: 48, mass: 0.15 });
  const dotY = useSpring(y, { stiffness: 950, damping: 48, mass: 0.15 });
  const frameX = useSpring(x, { stiffness: 210, damping: 21, mass: 0.65 });
  const frameY = useSpring(y, { stiffness: 210, damping: 21, mass: 0.65 });

  useEffect(() => {
    if (!active) return;
    const root = document.documentElement;
    root.classList.add("mansaj-cursor-on");

    const clearHideTimer = () => {
      if (hideTimer.current) {
        window.clearTimeout(hideTimer.current);
        hideTimer.current = null;
      }
    };
    /* Touch/pen pointers have no persistent cursor — auto-hide when idle. */
    const armTouchHide = () => {
      clearHideTimer();
      hideTimer.current = window.setTimeout(() => setVisible(false), IDLE_HIDE_MS);
    };

    const place = (e: PointerEvent) => {
      x.set(e.clientX);
      y.set(e.clientY);
      setVisible(true);
      if (e.pointerType !== "mouse") armTouchHide();
    };

    const onMove = (e: PointerEvent) => place(e);

    const onOver = (e: PointerEvent) => {
      if (!(e.target instanceof Element)) return;
      if (e.target.closest(FIELD_SELECTOR)) setVariant("field");
      else if (e.target.closest(INTERACTIVE_SELECTOR)) setVariant("link");
      else setVariant("default");
    };

    const onDown = (e: PointerEvent) => {
      setPressed(true);
      place(e);
    };
    const onUp = () => setPressed(false);
    const onGone = () => setVisible(false);

    window.addEventListener("pointermove", onMove, { passive: true });
    window.addEventListener("pointerover", onOver, { passive: true });
    window.addEventListener("pointerdown", onDown, { passive: true });
    window.addEventListener("pointerup", onUp, { passive: true });
    window.addEventListener("pointercancel", onGone, { passive: true });
    window.addEventListener("blur", onGone);
    document.documentElement.addEventListener("pointerleave", onGone);

    return () => {
      clearHideTimer();
      root.classList.remove("mansaj-cursor-on");
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerover", onOver);
      window.removeEventListener("pointerdown", onDown);
      window.removeEventListener("pointerup", onUp);
      window.removeEventListener("pointercancel", onGone);
      window.removeEventListener("blur", onGone);
      document.documentElement.removeEventListener("pointerleave", onGone);
    };
  }, [active, x, y]);

  if (!active) return null;

  const shown = visible && variant !== "field";

  return (
    <div
      aria-hidden="true"
      className="pointer-events-none fixed inset-0 z-[200]"
    >
      {/* Trailing square frame */}
      <motion.div style={{ x: frameX, y: frameY }} className="absolute left-0 top-0">
        <div className="-translate-x-1/2 -translate-y-1/2">
          <motion.div
            animate={{
              opacity: shown ? 1 : 0,
              scale: pressed ? 0.78 : variant === "link" ? 1.45 : 1,
              rotate: variant === "link" ? 45 : 0,
            }}
            transition={{ type: "spring", stiffness: 340, damping: 22 }}
            className="h-9 w-9 border-2 border-brand bg-brand/10"
          />
        </div>
      </motion.div>

      {/* Square dot — hugs the pointer */}
      <motion.div style={{ x: dotX, y: dotY }} className="absolute left-0 top-0">
        <div className="-translate-x-1/2 -translate-y-1/2">
          <motion.div
            animate={{
              opacity: shown ? 1 : 0,
              scale: pressed ? 0.65 : variant === "link" ? 0.55 : 1,
              rotate: variant === "link" ? 45 : 0,
            }}
            transition={{ type: "spring", stiffness: 520, damping: 30 }}
            className="h-2 w-2 bg-brand"
          />
        </div>
      </motion.div>
    </div>
  );
}
