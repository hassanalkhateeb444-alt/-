"use client";

import { useMemo, useState } from "react";
import Image from "next/image";
import { motion, useReducedMotion } from "framer-motion";
import { ArrowLeft, ArrowRight, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogTitle,
} from "@/components/ui/dialog";
import { useLang } from "@/lib/lang";
import { cn } from "@/lib/utils";
import { Container, Section, SectionHeading, openRequest } from "./shared";

/* ------------------------------------------------------------------ */
/* Types & data — testimonials copied VERBATIM from the approved plan  */
/* ------------------------------------------------------------------ */

type Category = "restaurants" | "legal" | "realty";
type Filter = Category | "all";

interface Project {
  id: string;
  no: string;
  nameAr: string;
  nameEn: string;
  category: Category;
  /** Live preview URL of the deployed website (opens in a new tab). */
  url: string;
  quoteAr: string;
  quoteEn: string;
}

const PROJECTS: Project[] = [
  {
    id: "alhamra",
    no: "01",
    url: "https://alhamraa.netlify.app/",
    nameAr: "مشويات الحمراء",
    nameEn: "Al-Hamra Grills",
    category: "restaurants",
    quoteAr:
      "ما شاء الله، الموقع مرتب ويشرح كل شيء بطريقة واضحة، من قائمة الطعام إلى العزائم والبوفيهات. أعجبني تنوع الخيارات والأسعار المناسبة، وسهولة الوصول للطلبات والفروع. كذلك الاهتمام بالتفاصيل يعطي انطباعًا جميلًا عن المكان واحترافية في التعامل. الله يوفقكم ويرزقكم من واسع فضله ❤️",
    quoteEn:
      "Praise be, the website is well organized and explains everything clearly — from the menu to catering orders and buffets. I liked the variety of options, the reasonable prices, and how easy it is to reach the ordering and branches. The attention to detail gives a lovely impression of the place and real professionalism. May God grant you success and abundant provision ❤️",
  },
  {
    id: "aisha",
    no: "02",
    url: "https://aishalaw.netlify.app/",
    nameAr: "مكتب المحامية عائشة محمد الصيعري",
    nameEn: "Law Office of Aisha Mohammed Al-Sayari",
    category: "legal",
    quoteAr:
      "أعجبني جدًا أسلوب عرض الخدمات القانونية، الموقع منظم واحترافي ويعطي شعورًا بالثقة والاطمئنان. وضوح الخدمات وسهولة التواصل والاهتمام بحقوق العملاء أمور تعطي انطباعًا إيجابيًا عن المكتب. نتمنى لكم دوام النجاح والتوفيق.",
    quoteEn:
      "I really liked the way the legal services are presented — the website is organized and professional and gives a feeling of trust and reassurance. Clear services, easy communication, and care for clients' rights all give a positive impression of the office. Wishing you continued success.",
  },
  {
    id: "maram",
    no: "03",
    url: "https://maramalfahmi.netlify.app",
    nameAr: "مكتب المحامية مرام الفهمي",
    nameEn: "Law Office of Maram Al-Fahmi",
    category: "legal",
    quoteAr:
      "بصراحة الموقع مميز واحترافي، وطريقة عرض المعلومات والخدمات واضحة جدًا. أكثر ما أعجبني سهولة التواصل وطلب الاستشارة، والاهتمام بالتفاصيل الذي يعكس الجدية والمصداقية. التعامل الراقي والوضوح من أهم الأمور التي يبحث عنها العميل. بالتوفيق لكم 🌷",
    quoteEn:
      "Honestly, the website is distinctive and professional, and the way information and services are presented is very clear. What I liked most is how easy it is to get in touch and request a consultation, and the attention to detail that reflects seriousness and credibility. Polite handling and clarity are among the most important things a client looks for. Wishing you success 🌷",
  },
  {
    id: "nibras",
    no: "04",
    url: "https://nebrasestate.netlify.app/",
    nameAr: "نبراس المدينة للعقار",
    nameEn: "Nibras Al-Madinah Real Estate",
    category: "realty",
    quoteAr:
      "موقع جميل ومرتب، وأكثر شيء أعجبني سهولة البحث عن العقارات وإمكانية تحديد الحي والمساحة والسعر. وجود خيارات متنوعة وأسعار تناسب أكثر من ميزانية يسهل على الشخص المقارنة والاختيار. شكرًا لكم على هذا التنظيم والاهتمام، ونتمنى لكم المزيد من النجاح 👏",
    quoteEn:
      "A beautiful, well-organized website — what I liked most is how easy it is to search for properties and narrow down by district, area, and price. Having varied options and prices that suit different budgets makes comparing and choosing easier. Thank you for this organization and care, and we wish you even more success 👏",
  },
  {
    id: "naseem",
    no: "05",
    url: "https://nnaseemgrill.netlify.app/",
    nameAr: "مشويات نسيم الرافدين",
    nameEn: "Naseem Al-Rafidain Grills",
    category: "restaurants",
    quoteAr:
      "أحب المواقع البسيطة التي توصلك للمعلومة بسرعة، وهذا الموقع فعلًا واضح وسهل الاستخدام. أعجبني تنوع قائمة الطعام والأسعار المناسبة، وكذلك سهولة الوصول إلى العنوان ووسائل التواصل. الاهتمام بالزبائن وحسن التعامل دائمًا يصنعان فرقًا كبيرًا. الله يبارك لكم في رزقكم.",
    quoteEn:
      "I love simple websites that get you to the information quickly, and this site is truly clear and easy to use. I liked the variety of the menu and the reasonable prices, as well as how easy it is to reach the address and contact channels. Caring for customers and good treatment always make a big difference. May God bless your provision.",
  },
  {
    id: "justwow",
    no: "06",
    url: "https://just-wow.netlify.app/",
    nameAr: "JUST WOW – واو وبس",
    nameEn: "JUST WOW",
    category: "restaurants",
    quoteAr:
      "واو فعلًا! تصميم شبابي ومختلف، والألوان وطريقة عرض الأصناف تعطي حماس لتجربة النكهات. الأسعار تبدو جميلة ومناسبة، والتنوع في الأصناف يعطي خيارات كثيرة. أعجبتني فكرة اختيار الخلطة حسب المزاج، لمسة إبداعية جميلة. استمروا بهذا الإبداع، ومنها للأفضل دائمًا 😍",
    quoteEn:
      "Wow, truly! A youthful, different design — the colors and the way the items are presented make you excited to try the flavors. The prices look good and reasonable, and the variety gives plenty of options. I loved the idea of choosing your mix by mood — a beautiful creative touch. Keep up this creativity, always onward and upward 😍",
  },
  {
    id: "alkawthar",
    no: "07",
    url: "https://alkawtharaden.netlify.app/",
    nameAr: "مطعم الكوثر للأكلات البحرية",
    nameEn: "Al-Kawthar Seafood Restaurant",
    category: "restaurants",
    quoteAr:
      "ما شاء الله، موقع جميل بطابع عدني أصيل. أعجبني عرض الأكلات البحرية وتنظيم الأقسام وسهولة التواصل مع المطعم. كذلك الاهتمام بالزبائن وحسن التعامل من الأمور التي تعطي انطباعًا طيبًا وتبني الثقة. الله يبارك لكم ويوسع رزقكم ❤️",
    quoteEn:
      "Praise be, a beautiful website with an authentic Aden character. I liked the presentation of the seafood dishes, the organized sections, and how easy it is to contact the restaurant. The care for customers and good treatment are among the things that leave a kind impression and build trust. May God bless you and expand your provision ❤️",
  },
];

const CATEGORY_LABEL: Record<Category, { ar: string; en: string }> = {
  restaurants: { ar: "مطاعم ومشويات", en: "Restaurants" },
  legal: { ar: "مكاتب وقانونية", en: "Legal offices" },
  realty: { ar: "عقارات", en: "Real estate" },
};

/** Expressive category photo shown on every project card + dialog. */
const CATEGORY_IMAGE: Record<Category, string> = {
  restaurants: "/images/cat-restaurants.jpg",
  legal: "/images/cat-legal.jpg",
  realty: "/images/cat-realty.jpg",
};

const CATEGORY_IMAGE_ALT: Record<Category, { ar: string; en: string }> = {
  restaurants: {
    ar: "أطباق مشويات على مائدة مطعم",
    en: "Grilled dishes served at a restaurant table",
  },
  legal: {
    ar: "ميزان العدالة وكتب قانونية في مكتب محاماة",
    en: "Scales of justice and law books in a law office",
  },
  realty: {
    ar: "شرفة عقار مطلة على أفق المدينة",
    en: "A real-estate terrace overlooking the city skyline",
  },
};

const FILTERS: Array<{ id: Filter; ar: string; en: string }> = [
  { id: "all", ar: "الكل", en: "All" },
  { id: "restaurants", ar: "مطاعم ومشويات", en: "Restaurants" },
  { id: "legal", ar: "مكاتب وقانونية", en: "Legal offices" },
  { id: "realty", ar: "عقارات", en: "Real estate" },
];

/* ------------------------------------------------------------------ */
/* Component                                                           */
/* ------------------------------------------------------------------ */

export function PortfolioSection() {
  const { t, dir } = useLang();
  const reduce = useReducedMotion();
  const [filter, setFilter] = useState<Filter>("all");
  const [openId, setOpenId] = useState<string | null>(null);
  const Arrow = dir === "rtl" ? ArrowLeft : ArrowRight;

  const fade = (delay: number) =>
    reduce
      ? {}
      : {
          initial: { opacity: 0, y: 18 },
          whileInView: { opacity: 1, y: 0 },
          viewport: { once: true, margin: "-60px" },
          transition: { duration: 0.55, delay, ease: [0.22, 1, 0.36, 1] as const },
        };

  const counts = useMemo(() => {
    const base: Record<Filter, number> = {
      all: PROJECTS.length,
      restaurants: 0,
      legal: 0,
      realty: 0,
    };
    for (const p of PROJECTS) base[p.category] += 1;
    return base;
  }, []);

  const filtered = filter === "all" ? PROJECTS : PROJECTS.filter((p) => p.category === filter);
  const openProject = openId ? PROJECTS.find((p) => p.id === openId) ?? null : null;

  return (
    <Section id="portfolio" ariaLabel={t({ ar: "أعمال منسج", en: "Mansaj's work" })}>
      <Container>
        <motion.div {...fade(0)}>
          <SectionHeading
            eyebrow={t({ ar: "أعمال منسج", en: "Mansaj's work" })}
            title={t({ ar: "مشاريع منسج على أرض الواقع", en: "Mansaj projects in the real world" })}
            description={t({
              ar: "تصفّح نماذج من المواقع التي طوّرناها لمجالات مختلفة، واضغط «معاينة الموقع» لتفتح الموقع الحقيقي وتجرّبه بنفسك، ثم أخبرنا بما تحتاجه لمشروعك.",
              en: "Browse a selection of the websites we built for different fields. Hit \"Preview website\" to open the live site and try it yourself, then tell us what your project needs.",
            })}
          />
        </motion.div>

        {/* Filter chips — squared, instant client-side filtering */}
        <motion.div
          {...fade(0.1)}
          role="group"
          aria-label={t({ ar: "تصفية المشاريع حسب المجال", en: "Filter projects by field" })}
          className="mb-8 flex flex-wrap gap-2"
        >
          {FILTERS.map((f) => {
            const active = filter === f.id;
            return (
              <button
                key={f.id}
                type="button"
                onClick={() => setFilter(f.id)}
                aria-pressed={active}
                className={cn(
                  "inline-flex min-h-[44px] items-center gap-2 rounded-none border px-4 py-2.5 text-sm font-semibold transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
                  active
                    ? "border-brand bg-brand text-brand-foreground"
                    : "border-border bg-card text-muted-foreground hover:border-brand hover:text-foreground"
                )}
              >
                {t({ ar: f.ar, en: f.en })}
                <span dir="ltr" className="font-mono text-xs opacity-70">
                  {counts[f.id]}
                </span>
              </button>
            );
          })}
        </motion.div>

        {/* Project cards — typographic, no fake screenshots */}
        <motion.div {...fade(0.15)} className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((p) => (
            <article
              key={p.id}
              className="group relative flex h-full flex-col border border-border bg-card transition-all hover:border-brand hover:shadow-[4px_4px_0_0_var(--brand)]"
            >
              {/* Expressive category photo banner */}
              <div className="relative h-36 shrink-0 overflow-hidden sm:h-40">
                <Image
                  src={CATEGORY_IMAGE[p.category]}
                  alt={t({
                    ar: CATEGORY_IMAGE_ALT[p.category].ar,
                    en: CATEGORY_IMAGE_ALT[p.category].en,
                  })}
                  fill
                  sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
                  className="object-cover transition-transform duration-500 group-hover:scale-[1.04]"
                />
                <div
                  aria-hidden="true"
                  className="absolute inset-0 bg-gradient-to-t from-deep/70 via-transparent to-transparent"
                />
                <span
                  dir="ltr"
                  className="absolute start-3 top-2.5 border border-border bg-card/95 px-1.5 py-0.5 font-mono text-xs font-bold text-brand"
                >
                  {p.no}
                </span>
                <span className="absolute bottom-2.5 end-3 bg-deep/85 px-2 py-1 text-[10px] font-semibold text-cream sm:text-xs">
                  {t({ ar: CATEGORY_LABEL[p.category].ar, en: CATEGORY_LABEL[p.category].en })}
                </span>
              </div>

              <div className="flex flex-1 flex-col p-5">
                <h3 className="line-clamp-2 min-h-[3.5rem] text-lg font-bold leading-snug">
                  {t({ ar: p.nameAr, en: p.nameEn })}
                </h3>
                <span className="mt-auto inline-flex items-center gap-1.5 pt-4 text-sm font-semibold text-brand">
                  {t({ ar: "عرض تقييم صاحب المشروع", en: "View project owner feedback" })}
                  <Arrow
                    aria-hidden="true"
                    className="h-4 w-4 rtl:group-hover:-translate-x-1 ltr:group-hover:translate-x-1"
                  />
                </span>
                {/* Live preview link — z-20 keeps it clickable above the
                    stretched dialog button, opens the deployed site */}
                <a
                  href={p.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={t({
                    ar: `معاينة موقع ${p.nameAr} في نافذة جديدة`,
                    en: `Preview the ${p.nameEn} website in a new tab`,
                  })}
                  className="relative z-20 mt-3 inline-flex min-h-[44px] items-center justify-center gap-2 border border-brand/40 bg-brand/5 px-3 py-2 text-sm font-semibold text-brand transition-colors hover:bg-brand hover:text-brand-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                >
                  <ExternalLink aria-hidden="true" className="h-4 w-4" />
                  {t({ ar: "معاينة الموقع", en: "Preview website" })}
                </a>
              </div>

              {/* Stretched click target keeps the markup valid and accessible */}
              <button
                type="button"
                onClick={() => setOpenId(p.id)}
                aria-label={t({
                  ar: `عرض تقييم صاحب مشروع ${p.nameAr}`,
                  en: `View project owner feedback for ${p.nameEn}`,
                })}
                className="absolute inset-0 z-10 rounded-none focus-visible:z-20 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              />
            </article>
          ))}
        </motion.div>
      </Container>

      {/* Project dialog — owner testimonial */}
      <Dialog open={openProject !== null} onOpenChange={(o) => !o && setOpenId(null)}>
        <DialogContent className="max-h-[85dvh] overflow-y-auto rounded-none text-start sm:rounded-none">
          {openProject ? (
            <>
              {/* Category photo banner */}
              <div className="relative -mx-6 -mt-6 mb-1 h-36 overflow-hidden sm:h-44">
                <Image
                  src={CATEGORY_IMAGE[openProject.category]}
                  alt=""
                  aria-hidden="true"
                  fill
                  sizes="560px"
                  className="object-cover"
                />
                <div
                  aria-hidden="true"
                  className="absolute inset-0 bg-gradient-to-t from-deep/60 via-transparent to-transparent"
                />
                <span
                  dir="ltr"
                  className="absolute start-4 top-4 border border-border bg-card/95 px-1.5 py-0.5 font-mono text-xs font-bold text-brand"
                >
                  {openProject.no}
                </span>
              </div>

              <div className="flex items-center gap-2.5">
                <DialogDescription className="m-0">
                  {t({
                    ar: CATEGORY_LABEL[openProject.category].ar,
                    en: CATEGORY_LABEL[openProject.category].en,
                  })}
                </DialogDescription>
              </div>
              <DialogTitle className="text-start text-xl font-bold leading-snug">
                {t({ ar: openProject.nameAr, en: openProject.nameEn })}
              </DialogTitle>

              <figure className="mt-1">
                <figcaption className="flex items-center gap-2 text-xs font-semibold text-brand">
                  <span aria-hidden="true" className="h-1.5 w-1.5 bg-brand" />
                  {t({ ar: "تقييم صاحب المشروع", en: "Feedback from the project owner" })}
                </figcaption>
                <blockquote className="mt-3 border-s-2 border-brand/60 ps-4 leading-relaxed text-foreground/90">
                  {t({ ar: openProject.quoteAr, en: openProject.quoteEn })}
                </blockquote>
              </figure>

              <DialogFooter className="mt-2 gap-2 sm:justify-between">
                <Button
                  asChild
                  variant="outline"
                  className="w-full rounded-none border-brand/50 font-semibold text-brand hover:bg-brand/10 hover:text-brand sm:w-auto"
                >
                  <a
                    href={openProject.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={t({
                      ar: `معاينة موقع ${openProject.nameAr} في نافذة جديدة`,
                      en: `Preview the ${openProject.nameEn} website in a new tab`,
                    })}
                  >
                    <ExternalLink aria-hidden="true" className="h-4 w-4" />
                    {t({ ar: "معاينة الموقع", en: "Preview website" })}
                  </a>
                </Button>
                <Button
                  onClick={() => openRequest()}
                  className="w-full rounded-none bg-brand font-semibold text-brand-foreground hover:bg-brand/90 sm:w-auto"
                >
                  {t({ ar: "أريد موقعًا مشابهًا لمشروعي", en: "I want a similar website" })}
                </Button>
              </DialogFooter>
            </>
          ) : null}
        </DialogContent>
      </Dialog>
    </Section>
  );
}
