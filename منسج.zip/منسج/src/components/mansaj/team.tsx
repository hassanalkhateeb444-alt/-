"use client";

import { useState } from "react";
import Image from "next/image";
import { motion, useReducedMotion } from "framer-motion";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogTitle,
} from "@/components/ui/dialog";
import { useLang } from "@/lib/lang";
import { CONTACTS, type ContactId } from "./data";
import { Container, MosaicMark, Section, SectionHeading, WhatsAppIcon } from "./shared";

/* ------------------------------------------------------------------ */
/* Data — descriptions/bullets strictly derived from the approved plan */
/* ------------------------------------------------------------------ */

interface MemberCopy {
  id: ContactId;
  firstAr: string;
  firstEn: string;
  descAr: string;
  descEn: string;
  bullets: Array<{ ar: string; en: string }>;
}

const MEMBERS: MemberCopy[] = [
  {
    id: "hasan",
    firstAr: "حسن",
    firstEn: "Hasan",
    descAr: "يقود فهم احتياج المشروع وتنسيق العمل ومتابعة التنفيذ.",
    descEn:
      "Leads understanding the project's needs, coordinating the work, and following up on implementation.",
    bullets: [
      { ar: "فهم احتياج المشروع", en: "Understanding the project's needs" },
      { ar: "تنسيق العمل ومتابعة التنفيذ", en: "Coordinating the work and following up on implementation" },
      { ar: "التواصل مع أصحاب المشاريع", en: "Communicating with project owners" },
    ],
  },
  {
    id: "alawi",
    firstAr: "علوي",
    firstEn: "Alawi",
    descAr: "يساهم في تنفيذ وتطوير مشاريع الويب ضمن فريق منسج.",
    descEn: "Contributes to implementing and developing web projects within the Mansaj team.",
    bullets: [
      { ar: "تنفيذ مشاريع الويب", en: "Implementing web projects" },
      { ar: "تطوير وتحسين المواقع", en: "Developing and improving websites" },
    ],
  },
];

/* ------------------------------------------------------------------ */
/* Component                                                           */
/* ------------------------------------------------------------------ */

export function TeamSection() {
  const { t } = useLang();
  const reduce = useReducedMotion();
  const [personId, setPersonId] = useState<ContactId | null>(null);

  const fade = (delay: number) =>
    reduce
      ? {}
      : {
          initial: { opacity: 0, y: 18 },
          whileInView: { opacity: 1, y: 0 },
          viewport: { once: true, margin: "-60px" },
          transition: { duration: 0.55, delay, ease: [0.22, 1, 0.36, 1] as const },
        };

  const person = personId ? MEMBERS.find((m) => m.id === personId) ?? null : null;
  const personContact = person ? CONTACTS[person.id] : null;

  return (
    <Section id="team" ariaLabel={t({ ar: "فريق منسج", en: "Mansaj team" })}>
      <Container>
        <motion.div {...fade(0)}>
          <SectionHeading
            eyebrow={t({ ar: "الفريق", en: "The team" })}
            title={t({
              ar: "وراء منسج فريق يعمل على تحويل الفكرة إلى تجربة.",
              en: "Behind Mansaj, a team working to turn the idea into an experience.",
            })}
          />
        </motion.div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {/* Brand card */}
          <motion.article
            {...fade(0.1)}
            className="relative flex h-full flex-col overflow-hidden border border-brand/30 bg-deep p-6 text-deep-foreground sm:p-7 md:col-span-2 lg:col-span-1"
          >
            <div aria-hidden="true" className="absolute inset-0 bg-blueprint opacity-25" />
            <MosaicMark className="pointer-events-none absolute -top-2 end-4 h-14 w-18 text-cream/15" />
            <div className="relative">
              <span className="relative block h-12 w-12 overflow-hidden rounded-sm bg-cream p-1.5 dark:bg-cream">
                <Image
                  src="/images/mansaj-logo.png"
                  alt={t({ ar: "شعار منسج الرقمية", en: "Mansaj Digital logo" })}
                  fill
                  sizes="48px"
                  className="object-contain dark:hidden"
                />
                <Image
                  src="/images/mansaj-logo-light.png"
                  alt=""
                  aria-hidden="true"
                  fill
                  sizes="48px"
                  className="hidden object-contain dark:block"
                />
              </span>
              <h3 className="mt-4 text-xl font-bold">{t({ ar: "منسج الرقمية", en: "Mansaj Digital" })}</h3>
              <p className="mt-2.5 text-sm leading-relaxed text-deep-foreground/85">
                {t({
                  ar: "نبني حضورك على الويب: من فهم الاحتياج إلى التسليم والدعم.",
                  en: "We build your web presence: from understanding the need to delivery and support.",
                })}
              </p>
            </div>
            <div aria-hidden="true" className="relative mt-auto flex items-center gap-1 pt-6">
              <span className="h-2 w-2 bg-brand" />
              <span className="h-2 w-2 bg-brand/45" />
              <span className="h-2 w-2 bg-deep-foreground/25" />
            </div>
          </motion.article>

          {/* Team member cards */}
          {MEMBERS.map((m, i) => {
            const c = CONTACTS[m.id];
            const isHasan = m.id === "hasan";
            return (
              <motion.article
                key={m.id}
                {...fade(0.15 + i * 0.08)}
                className="flex h-full flex-col border border-border bg-card p-6 transition-all hover:border-brand hover:shadow-[4px_4px_0_0_var(--brand)]"
              >
                {isHasan && c.photo ? (
                  <span className="relative block h-40 w-40 shrink-0 overflow-hidden rounded-sm border border-border">
                    <Image
                      src={c.photo}
                      alt={t({ ar: c.ar, en: c.en })}
                      fill
                      sizes="160px"
                      className="object-cover"
                    />
                  </span>
                ) : (
                  <span
                    aria-hidden="true"
                    className="flex h-40 w-40 shrink-0 flex-col items-center justify-center gap-3 rounded-sm border border-deep/20 bg-deep text-deep-foreground"
                  >
                    <span className="text-5xl font-bold leading-none">
                      {t({ ar: "ع", en: "A" })}
                    </span>
                    <span className="flex items-center gap-1">
                      <span className="h-1.5 w-1.5 bg-brand" />
                      <span className="h-1.5 w-1.5 bg-brand/50" />
                      <span className="h-1.5 w-1.5 bg-deep-foreground/30" />
                    </span>
                  </span>
                )}

                <h3 className="mt-5 text-lg font-bold">{t({ ar: c.ar, en: c.en })}</h3>
                <p className="mt-1 text-sm font-semibold text-brand">
                  {t({ ar: c.roleAr, en: c.roleEn })}
                </p>
                <p className="mt-2.5 text-sm leading-relaxed text-muted-foreground">
                  {t({ ar: m.descAr, en: m.descEn })}
                </p>
                <div className="mt-auto pt-5">
                  <Button
                    variant="outline"
                    onClick={() => setPersonId(m.id)}
                    className="h-11 rounded-sm px-5 font-semibold"
                  >
                    {isHasan
                      ? t({ ar: "تعرّف على حسن أكثر", en: "More about Hasan" })
                      : t({ ar: "تعرّف على علوي أكثر", en: "More about Alawi" })}
                  </Button>
                </div>
              </motion.article>
            );
          })}
        </div>
      </Container>

      {/* Person dialog — extended intro + WhatsApp contact */}
      <Dialog open={person !== null} onOpenChange={(o) => !o && setPersonId(null)}>
        <DialogContent className="max-h-[85dvh] overflow-y-auto rounded-none text-start sm:rounded-none">
          {person && personContact ? (
            <>
              <div className="flex items-center gap-3.5">
                {person.id === "hasan" && personContact.photo ? (
                  <span className="relative block h-12 w-12 shrink-0 overflow-hidden rounded-sm border border-border">
                    <Image
                      src={personContact.photo}
                      alt=""
                      aria-hidden="true"
                      fill
                      sizes="48px"
                      className="object-cover"
                    />
                  </span>
                ) : (
                  <span
                    aria-hidden="true"
                    className="flex h-12 w-12 shrink-0 items-center justify-center rounded-sm bg-deep text-lg font-bold text-deep-foreground"
                  >
                    {t({ ar: "ع", en: "A" })}
                  </span>
                )}
                <div>
                  <DialogTitle className="text-start text-lg font-bold">
                    {t({ ar: personContact.ar, en: personContact.en })}
                  </DialogTitle>
                  <DialogDescription className="mt-0.5 text-start">
                    {t({ ar: personContact.roleAr, en: personContact.roleEn })}
                  </DialogDescription>
                </div>
              </div>

              <p className="text-sm leading-relaxed text-muted-foreground">
                {t({ ar: person.descAr, en: person.descEn })}
              </p>

              <ul className="space-y-2.5 border border-border bg-secondary/50 p-4">
                {person.bullets.map((b) => (
                  <li key={b.ar} className="flex items-start gap-2.5 text-sm">
                    <span aria-hidden="true" className="mt-1.5 h-1.5 w-1.5 shrink-0 bg-brand" />
                    {t({ ar: b.ar, en: b.en })}
                  </li>
                ))}
              </ul>

              <DialogFooter className="mt-1 gap-2">
                <Button
                  asChild
                  className="w-full rounded-sm bg-brand font-semibold text-brand-foreground hover:bg-brand/90 sm:w-auto"
                >
                  <a
                    href={`https://wa.me/${personContact.wa}`}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <WhatsAppIcon className="h-4 w-4" />
                    {t({
                      ar: `تواصل مع ${person.firstAr} عبر واتساب`,
                      en: `Chat with ${person.firstEn} on WhatsApp`,
                    })}
                  </a>
                </Button>
              </DialogFooter>
            </>
          ) : null}
        </DialogContent>
      </Dialog>
    </Section>
  );
}
