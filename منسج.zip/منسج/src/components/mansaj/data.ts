import {
  Building2,
  ShoppingBag,
  CreditCard,
  MousePointerClick,
  UserRound,
  Landmark,
  UtensilsCrossed,
  CalendarCheck2,
  Wrench,
  ShieldCheck,
  PlugZap,
  Sparkles,
  House,
  Globe,
  Layers,
  LayoutGrid,
  Workflow,
  Users,
  CircleHelp,
  Mail,
  type LucideIcon,
} from "lucide-react";

/* ------------------------------------------------------------------ */
/* Services — the 11 approved services (copy from the approved plan)   */
/* ------------------------------------------------------------------ */

export type ServiceId =
  | "corporate"
  | "store"
  | "store-payment"
  | "landing"
  | "personal"
  | "realty"
  | "restaurant"
  | "booking"
  | "improve"
  | "support"
  | "api";

export interface Service {
  id: ServiceId;
  icon: LucideIcon;
  ar: string;
  en: string;
  arDesc: string;
  enDesc: string;
}

export const SERVICES: Service[] = [
  {
    id: "corporate",
    icon: Building2,
    ar: "مواقع تعريفية للشركات والأنشطة",
    en: "Corporate & business websites",
    arDesc: "عرّف بخدماتك وفريقك ومعلوماتك المهمة في موقع واضح يعكس هوية نشاطك.",
    enDesc: "Introduce your services, team, and key information in a clear website that reflects your identity.",
  },
  {
    id: "store",
    icon: ShoppingBag,
    ar: "متاجر إلكترونية",
    en: "Online stores",
    arDesc: "اعرض منتجاتك بطريقة مرتبة، وسهّل على عملائك اكتشافها والوصول إلى تفاصيلها.",
    enDesc: "Present your products in an organized way and make them easy to discover.",
  },
  {
    id: "store-payment",
    icon: CreditCard,
    ar: "متاجر مع بوابات دفع",
    en: "Stores with payment gateways",
    arDesc: "متجر يتيح عرض المنتجات وإتمام الدفع عبر خيارات الدفع التي يدعمها المشروع والبلد.",
    enDesc: "A store that supports product display and checkout via the payment options available in your country.",
  },
  {
    id: "landing",
    icon: MousePointerClick,
    ar: "صفحات هبوط للحملات والخدمات",
    en: "Landing pages",
    arDesc: "صفحة مركّزة تشرح عرضك أو حملتك وتوجّه الزائر إلى إجراء محدد.",
    enDesc: "A focused page that explains your offer or campaign and drives one clear action.",
  },
  {
    id: "personal",
    icon: UserRound,
    ar: "مواقع شخصية ومعارض أعمال",
    en: "Personal sites & portfolios",
    arDesc: "قدّم خبرتك ومشاريعك بطريقة احترافية تسهّل على المهتمين التعرف إليك والتواصل معك.",
    enDesc: "Present your expertise and projects professionally so the right people reach out.",
  },
  {
    id: "realty",
    icon: Landmark,
    ar: "مواقع عقارية",
    en: "Real estate websites",
    arDesc: "نظّم العقارات وتفاصيلها، وسهّل على الزوار استكشاف الخيارات والتواصل بشأنها.",
    enDesc: "Organize listings and details so visitors can explore options and get in touch.",
  },
  {
    id: "restaurant",
    icon: UtensilsCrossed,
    ar: "مواقع مطاعم وقوائم طعام وطلبات",
    en: "Restaurant sites & menus",
    arDesc: "اعرض قائمة الطعام ومعلومات المطعم وطرق الطلب والتواصل في مكان واحد.",
    enDesc: "Your menu, restaurant info, and ordering channels in one clear place.",
  },
  {
    id: "booking",
    icon: CalendarCheck2,
    ar: "مواقع حجز مواعيد أو خدمات",
    en: "Booking websites",
    arDesc: "رتّب معلومات الخدمة وخيارات الحجز بما يناسب طريقة عملك.",
    enDesc: "Organize service information and booking options around the way you work.",
  },
  {
    id: "improve",
    icon: Wrench,
    ar: "تطوير وتحسين مواقع قائمة",
    en: "Improving existing websites",
    arDesc: "نراجع احتياج الموقع الحالي ونطوّر الأجزاء المتفق عليها لتحسين وضوحه أو وظائفه.",
    enDesc: "We review your current site and improve the agreed parts for clarity or functionality.",
  },
  {
    id: "support",
    icon: ShieldCheck,
    ar: "صيانة ودعم فني واستضافة",
    en: "Maintenance, support & hosting",
    arDesc: "خيارات دعم وصيانة واستضافة تُحدّد تفاصيلها ومدتها ضمن اتفاق واضح للمشروع.",
    enDesc: "Support, maintenance, and hosting options defined in a clear project agreement.",
  },
  {
    id: "api",
    icon: PlugZap,
    ar: "ربط خدمات وواجهات برمجية (API)",
    en: "API & service integrations",
    arDesc: "ربط موقعك بخدمات أو أنظمة خارجية عند توفر الواجهات والصلاحيات المناسبة.",
    enDesc: "Connect your site to external services when the APIs and permissions are available.",
  },
];

/* ------------------------------------------------------------------ */
/* Activity domains for the request form                               */
/* ------------------------------------------------------------------ */

export type DomainId =
  | "company"
  | "store"
  | "restaurant"
  | "realty"
  | "booking"
  | "other";

export interface Domain {
  id: DomainId;
  icon: LucideIcon;
  ar: string;
  en: string;
  services: ServiceId[];
}

const ALL_SERVICES: ServiceId[] = [
  "corporate",
  "store",
  "store-payment",
  "landing",
  "personal",
  "realty",
  "restaurant",
  "booking",
  "improve",
  "support",
  "api",
];

export const DOMAINS: Domain[] = [
  {
    id: "company",
    icon: Building2,
    ar: "شركة أو نشاط خدمي",
    en: "Company or service business",
    services: ["corporate", "landing", "personal", "improve", "support", "api"],
  },
  {
    id: "store",
    icon: ShoppingBag,
    ar: "متجر",
    en: "Store",
    services: ["store", "store-payment", "landing", "improve", "support", "api"],
  },
  {
    id: "restaurant",
    icon: UtensilsCrossed,
    ar: "مطعم أو كافتيريا",
    en: "Restaurant or cafeteria",
    services: ["restaurant", "landing", "improve", "support", "api"],
  },
  {
    id: "realty",
    icon: Landmark,
    ar: "عقار أو مكتب عقاري",
    en: "Real estate office",
    services: ["realty", "landing", "improve", "support", "api"],
  },
  {
    id: "booking",
    icon: CalendarCheck2,
    ar: "حجز مواعيد أو خدمات",
    en: "Appointments & bookings",
    services: ["booking", "landing", "improve", "support", "api"],
  },
  {
    id: "other",
    icon: Sparkles,
    ar: "مجال آخر",
    en: "Another field",
    services: ALL_SERVICES,
  },
];

/* ------------------------------------------------------------------ */
/* Contact people (WhatsApp)                                           */
/* ------------------------------------------------------------------ */

export type ContactId = "hasan" | "alawi";

export interface ContactPerson {
  id: ContactId;
  ar: string;
  en: string;
  roleAr: string;
  roleEn: string;
  phoneDisplay: string;
  wa: string;
  photo?: string;
  initials: string;
}

export const CONTACTS: Record<ContactId, ContactPerson> = {
  hasan: {
    id: "hasan",
    ar: "حسن الخطيب",
    en: "Hasan Al-Khatib",
    roleAr: "مدير منسج الرقمية",
    roleEn: "Manager, Mansaj Digital",
    phoneDisplay: "+967 771 648 640",
    wa: "967771648640",
    photo: "/images/hasan.jpg",
    initials: "ح",
  },
  alawi: {
    id: "alawi",
    ar: "علوي المحضار",
    en: "Alawi Al-Muhdar",
    roleAr: "مطوّر ضمن فريق منسج",
    roleEn: "Developer at Mansaj",
    phoneDisplay: "+967 771 797 591",
    wa: "967771797591",
    initials: "ع",
  },
};

/* ------------------------------------------------------------------ */
/* Brand constants                                                     */
/* ------------------------------------------------------------------ */

export const BRAND = {
  ar: "منسج الرقمية",
  en: "Mansaj Digital",
  instagram: "https://www.instagram.com/mansagdigital/",
  instagramHandle: "@mansagdigital",
};

export const STATS = [
  { value: 150, suffix: "+", ar: "موقع بُني خلال السنة الماضية", en: "websites built last year" },
  { value: 150, suffix: "", ar: "عميل خلال السنة الماضية", en: "clients last year" },
  { value: 1, suffix: "+", ar: "سنة خبرة", en: "year of experience" },
  { value: 356, suffix: "", ar: "ساعة عمل فعلية", en: "actual working hours" },
];

/* ------------------------------------------------------------------ */
/* Navigation sections (shared by header, dock, and menus)             */
/* ------------------------------------------------------------------ */

export interface NavItem {
  id: string;
  ar: string;
  en: string;
  icon: LucideIcon;
}

export const NAV_ITEMS: NavItem[] = [
  { id: "home", ar: "الرئيسية", en: "Home", icon: House },
  { id: "why-site", ar: "لماذا الموقع", en: "Why a website", icon: Globe },
  { id: "services", ar: "الخدمات", en: "Services", icon: Layers },
  { id: "portfolio", ar: "الأعمال", en: "Work", icon: LayoutGrid },
  { id: "process", ar: "طريقة العمل", en: "Process", icon: Workflow },
  { id: "team", ar: "الفريق", en: "Team", icon: Users },
  { id: "faq", ar: "أسئلة شائعة", en: "FAQ", icon: CircleHelp },
  { id: "contact", ar: "تواصل", en: "Contact", icon: Mail },
];
