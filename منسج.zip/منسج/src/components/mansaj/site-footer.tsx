"use client";

import Image from "next/image";
import { Instagram } from "lucide-react";
import { useLang } from "@/lib/lang";
import { BRAND, CONTACTS, type ContactId } from "./data";
import { Container, WhatsAppIcon, scrollToSection } from "./shared";

const SECTIONS: Array<{ id: string; ar: string; en: string }> = [
  { id: "services", ar: "الخدمات", en: "Services" },
  { id: "portfolio", ar: "الأعمال", en: "Work" },
  { id: "process", ar: "طريقة العمل", en: "Process" },
  { id: "team", ar: "الفريق", en: "Team" },
  { id: "contact", ar: "تواصل", en: "Contact" },
];

const CONTACT_ORDER: ContactId[] = ["hasan", "alawi"];

/* ------------------------------------------------------------------ */
/* Component                                                           */
/* ------------------------------------------------------------------ */

export function SiteFooter() {
  const { t, dir } = useLang();
  const year = new Date().getFullYear();

  return (
    <footer className="mt-auto border-t-2 border-brand/50 bg-deep text-deep-foreground">
      <Container className="grid gap-10 py-12 md:grid-cols-[1.2fr_1fr_1.2fr] md:gap-8">
        {/* Brand */}
        <div>
          <span className="flex items-center gap-3">
            <span className="relative block h-11 w-11 shrink-0 overflow-hidden rounded-sm bg-cream p-1.5 dark:bg-cream">
              <Image
                src="/images/mansaj-logo.png"
                alt={t({ ar: "شعار منسج الرقمية", en: "Mansaj Digital logo" })}
                fill
                sizes="44px"
                className="object-contain dark:hidden"
              />
              <Image
                src="/images/mansaj-logo-light.png"
                alt=""
                aria-hidden="true"
                fill
                sizes="44px"
                className="hidden object-contain dark:block"
              />
            </span>
            <span className="flex flex-col leading-tight">
              <span className="text-base font-bold">{t({ ar: "منسج الرقمية", en: "Mansaj Digital" })}</span>
              <span className="text-xs text-deep-foreground/70" dir={dir === "rtl" ? "ltr" : "rtl"}>
                {t({ ar: "Mansaj Digital", en: "منسج الرقمية" })}
              </span>
            </span>
          </span>
          <p className="mt-5 max-w-xs text-sm leading-relaxed text-deep-foreground/85">
            {t({ ar: "مشروعك يستحق موقعًا يعمل لأجله.", en: "Your project deserves a website that works for it." })}
          </p>
        </div>

        {/* Sections */}
        <nav aria-label={t({ ar: "روابط الأقسام", en: "Section links" })}>
          <p className="text-sm font-bold">{t({ ar: "أقسام الموقع", en: "Site sections" })}</p>
          <ul className="mt-4 space-y-2.5">
            {SECTIONS.map((s) => (
              <li key={s.id}>
                <button
                  type="button"
                  onClick={() => scrollToSection(s.id)}
                  className="group inline-flex min-h-[36px] items-center gap-2 text-sm text-deep-foreground/85 transition-colors hover:text-brand focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                >
                  <span aria-hidden="true" className="h-1.5 w-1.5 bg-brand/60 transition-colors group-hover:bg-brand" />
                  {t({ ar: s.ar, en: s.en })}
                </button>
              </li>
            ))}
          </ul>
        </nav>

        {/* Contacts + Instagram */}
        <div>
          <p className="text-sm font-bold">{t({ ar: "تواصل", en: "Contact" })}</p>
          <ul className="mt-4 space-y-4">
            {CONTACT_ORDER.map((id) => {
              const c = CONTACTS[id];
              return (
                <li key={id} className="flex items-start gap-2.5">
                  <WhatsAppIcon className="mt-0.5 h-4 w-4 shrink-0 text-brand" />
                  <div>
                    <p className="text-sm font-semibold">
                      {t({ ar: c.ar, en: c.en })}
                      <span className="font-normal text-deep-foreground/60">
                        {" · "}
                        {t({ ar: c.roleAr, en: c.roleEn })}
                      </span>
                    </p>
                    <a
                      href={`https://wa.me/${c.wa}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      dir="ltr"
                      className="mt-0.5 inline-block font-mono text-sm text-deep-foreground/85 underline-offset-4 transition-colors hover:text-brand hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                    >
                      {c.phoneDisplay}
                    </a>
                  </div>
                </li>
              );
            })}
          </ul>

          <a
            href={BRAND.instagram}
            target="_blank"
            rel="noopener noreferrer"
            className="group mt-6 flex items-start gap-2.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            <Instagram className="mt-0.5 h-4 w-4 shrink-0 text-brand" aria-hidden="true" />
            <span>
              <span
                dir="ltr"
                className="block font-mono text-sm font-semibold transition-colors group-hover:text-brand"
              >
                {BRAND.instagramHandle}
              </span>
              <span className="mt-0.5 block text-xs text-deep-foreground/70">
                {t({
                  ar: "الحساب الرسمي لعلامة منسج الرقمية",
                  en: "The official account of Mansaj Digital",
                })}
              </span>
            </span>
          </a>
        </div>
      </Container>

      {/* Bottom bar */}
      <div className="border-t border-deep-foreground/15">
        <Container className="flex flex-col items-center justify-between gap-2 py-5 pb-[max(1.25rem,env(safe-area-inset-bottom))] text-center sm:flex-row sm:text-start">
          <p className="text-xs text-deep-foreground/75">
            {t({
              ar: `© ${year} منسج الرقمية — Mansaj Digital`,
              en: `© ${year} Mansaj Digital`,
            })}
          </p>
          <p className="text-xs text-deep-foreground/75">
            {t({ ar: "صُنع بعناية من فريق منسج", en: "Crafted with care by the Mansaj team" })}
          </p>
        </Container>
      </div>
    </footer>
  );
}
