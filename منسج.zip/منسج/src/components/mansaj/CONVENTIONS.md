# Mansaj Digital — Component Conventions (READ FULLY BEFORE CODING)

Bilingual (Arabic RTL default / English LTR) marketing site for "منسج الرقمية — Mansaj Digital".
Next.js 16 App Router, TypeScript, Tailwind CSS 4, shadcn/ui (New York), framer-motion, lucide-react.

## Mandatory reading before writing any component
1. `/home/z/my-project/src/lib/lang.tsx` — language provider + `useLang()` hook
2. `/home/z/my-project/src/components/mansaj/shared.tsx` — `Section`, `Container`, `SectionHeading`, `MosaicMark`, `SquaresStrip`, `CountUp`, `WhatsAppIcon`, `openRequest()`, `scrollToSection()`
3. `/home/z/my-project/src/components/mansaj/data.ts` — `SERVICES`, `DOMAINS`, `CONTACTS`, `BRAND`, `STATS`
4. `/home/z/my-project/src/components/mansaj/hero.tsx` — reference implementation for tone/motion/style
5. The plan with ALL approved Arabic copy: `/home/z/my-project/upload/خطة بناء موقع منسج الرقمية.md`

## Hard rules
- Every component file starts with `"use client";`
- NEVER edit files you do not own. Only create/modify the files assigned to you.
- NO new routes/pages. One-page site composed of section components.
- All user-visible text MUST be bilingual via the pattern:
  `const { t, dir } = useLang();` then `t({ ar: "نص عربي", en: "English text" })`
  For arrays/objects: `t({ ar: [...], en: [...] })` — works for any type.
- Arabic copy: take it VERBATIM from the approved plan file. Do not paraphrase the approved marketing copy. English copy: concise professional translation you write yourself.
- RTL-safe spacing/logic ONLY: use `ms-`, `me-`, `ps-`, `pe-`, `start-`, `end-`, `text-start`, `border-s`, etc. NEVER `ml/mr/pl/pr/left/right` for directional meaning. Arrows pointing "forward" should flip with dir (see hero.tsx `dir === "rtl" ? ArrowLeft : ArrowRight`).
- Use existing shadcn/ui components (`@/components/ui/*`): Button, Card, Badge, Accordion, Dialog, Tabs, etc. Do not reinvent.
- Design language ("Mansaj engineering"): geometric, NON-circular. Squared corners (`rounded-none`/`rounded-sm`), cut/sharp edges, grid lines (`bg-blueprint` utility exists), mosaic square accents (`MosaicMark`, `SquaresStrip`). NO rounded-full on cards/buttons (avatars inside photos ok). NO blue/indigo colors — palette is brand turquoise (`bg-brand`, `text-brand`, `border-brand`), deep teal (`bg-deep`), cream (`bg-cream`), plus theme tokens.
- Hover shadow accent idiom: `hover:shadow-[4px_4px_0_0_var(--brand)]` (see hero cards).
- Motion: framer-motion, subtle only (fade/slide 12–20px). Always `const reduce = useReducedMotion()` and skip animation when true (see hero.tsx `fade()` helper). No parallax, no particles, no letter-by-letter text.
- Icons: lucide-react only, size h-4/h-5/h-6. WhatsApp icon: use `WhatsAppIcon` from shared.tsx (lucide has no WhatsApp).
- Images: `next/image` with width/height or fill + sizes. Real brand photos only: `/images/hasan.jpg` (Hasan Al-Khatib, manager), `/images/mansaj-logo.png` (logo, dark-on-cream), `/images/mansaj-logo-light.png` (cream logo for dark backgrounds).
- Sections must be reachable by anchor: wrap content with `<Section id="...">` from shared.tsx.
- Long lists: constrain height + `overflow-y-auto` when content could exceed ~400px.
- Accessibility: semantic headings (h2 inside sections), aria-labels on icon-only buttons, `aria-hidden="true"` on decorative elements, focus-visible styles preserved.
- Responsive mobile-first: base styles for phones, then `sm:` `lg:` enhancements. Touch targets ≥ 44px.
- Do NOT invent facts: no fake prices, no fake client counts beyond approved stats (150+ sites, 150 clients, 1+ year, 356 hours), no fake social proof, no invented team skills.
- ESLint must pass (`bun run lint`). No unused imports/vars. No `any` unless unavoidable.

## Style notes
- Section rhythm: `Section` already adds py; inside use `Container`.
- Headings: use `SectionHeading` (eyebrow + title + description) with approved plan copy.
- Cards: `border border-border bg-card` + hover border-brand. Do not over-shadow.
- Buttons: primary `bg-primary text-primary-foreground`; brand accent `bg-brand text-brand-foreground hover:bg-brand/90`; secondary `variant="outline"`.
- Trust chips: small squares (`h-1.5 w-1.5 bg-brand`) as separators/markers, not dots/circles.
