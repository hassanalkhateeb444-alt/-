"use client";

import Image from "next/image";
import { useTheme } from "next-themes";
import { Moon, Sun } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLang } from "@/lib/lang";
import { NAV_ITEMS } from "./data";
import { openRequest, scrollToSection } from "./shared";
import { cn } from "@/lib/utils";

function Logo({ className }: { className?: string }) {
  const { t } = useLang();
  return (
    <span className={cn("flex items-center gap-2.5", className)}>
      <span className="relative block h-9 w-9 overflow-hidden rounded-sm bg-cream p-1 dark:bg-cream">
        <Image
          src="/images/mansaj-logo.png"
          alt={t({ ar: "شعار منسج الرقمية", en: "Mansaj Digital logo" })}
          fill
          sizes="36px"
          priority
          className="object-contain dark:hidden"
        />
        <Image
          src="/images/mansaj-logo-light.png"
          alt=""
          aria-hidden="true"
          fill
          sizes="36px"
          className="hidden object-contain dark:block"
        />
      </span>
      <span className="flex flex-col leading-none">
        <span className="text-base font-bold">{t({ ar: "منسج", en: "Mansaj" })}</span>
        <span className="text-[11px] font-medium text-muted-foreground">
          {t({ ar: "الرقمية · Digital", en: "Digital · الرقمية" })}
        </span>
      </span>
    </span>
  );
}

function ThemeToggle() {
  const { setTheme } = useTheme();
  const { t } = useLang();
  return (
    <Button
      variant="outline"
      size="icon"
      aria-label={t({
        ar: "تبديل المظهر بين الداكن والفاتح",
        en: "Toggle dark and light mode",
      })}
      onClick={() => {
        // Read the live class to stay correct even before next-themes hydration.
        const isDark = document.documentElement.classList.contains("dark");
        setTheme(isDark ? "light" : "dark");
      }}
      className="rounded-sm"
    >
      <Sun className="h-4 w-4 dark:hidden" />
      <Moon className="hidden h-4 w-4 dark:block" />
    </Button>
  );
}

function LangToggle() {
  const { lang, setLang, t } = useLang();
  return (
    <Button
      variant="outline"
      size="sm"
      aria-label={t({ ar: "Switch to English", en: "التبديل إلى العربية" })}
      onClick={() => setLang(lang === "ar" ? "en" : "ar")}
      className="h-9 gap-1 rounded-sm px-3 font-semibold"
    >
      {lang === "ar" ? "EN" : "عربي"}
    </Button>
  );
}

export function SiteHeader() {
  const { t } = useLang();

  const go = (id: string) => {
    scrollToSection(id);
  };

  return (
    <header className="fixed inset-x-0 top-0 z-50 border-b border-border/70 bg-background/85 backdrop-blur-md">
      <div className="mx-auto flex h-16 w-full max-w-6xl items-center justify-between gap-3 px-4 sm:px-6">
        <button
          onClick={() => go("home")}
          aria-label={t({ ar: "الانتقال إلى البداية", en: "Go to top" })}
          className="shrink-0"
        >
          <Logo />
        </button>

        {/* Desktop nav */}
        <nav aria-label={t({ ar: "التنقل الرئيسي", en: "Main navigation" })} className="hidden lg:block">
          <ul className="flex items-center gap-1">
            {NAV_ITEMS.slice(1, 7).map((item) => (
              <li key={item.id}>
                <button
                  onClick={() => go(item.id)}
                  className="rounded-sm px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
                >
                  {t({ ar: item.ar, en: item.en })}
                </button>
              </li>
            ))}
          </ul>
        </nav>

        <div className="flex items-center gap-2">
          <LangToggle />
          <ThemeToggle />
          <Button
            onClick={() => openRequest()}
            className="hidden rounded-sm font-semibold sm:inline-flex"
          >
            {t({ ar: "ابدأ مشروعك", en: "Start your project" })}
          </Button>
        </div>
      </div>
    </header>
  );
}

export { Logo, ThemeToggle, LangToggle };
