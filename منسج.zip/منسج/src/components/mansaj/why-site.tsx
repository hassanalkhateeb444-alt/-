"use client";

import { motion, useReducedMotion } from "framer-motion";
import Image from "next/image";
import {
  ArrowLeft,
  ArrowRight,
  Clock,
  Layers,
  LayoutGrid,
  MessageSquare,
} from "lucide-react";
import { useLang } from "@/lib/lang";
import { Button } from "@/components/ui/button";
import { Container, Section, SectionHeading, openRequest } from "./shared";

const BULLETS = [
  {
    icon: LayoutGrid,
    ar: "اعرض خدماتك ومعلوماتك في مكان واحد تملكه وتتحكم بمحتواه.",
    en: "Present your services and information in one place you own and control.",
  },
  {
    icon: Clock,
    ar: "اجعل تفاصيل مشروعك متاحة للزائر في أي وقت.",
    en: "Keep your project details available to visitors at any time.",
  },
  {
    icon: Layers,
    ar: "رتّب المنتجات أو العقارات أو الحجوزات بحسب طبيعة نشاطك.",
    en: "Arrange products, properties, or bookings around the nature of your business.",
  },
  {
    icon: MessageSquare,
    ar: "اجعل التواصل والطلب أوضح وأسهل من البحث بين منشورات متفرقة.",
    en: "Make contact and orders clearer and easier than searching through scattered posts.",
  },
];

/** CSS-only website mockup — geometric blocks echoing the Mansaj mosaic, no images. */
function WebsiteMockup() {
  const { t } = useLang();
  return (
    <div
      aria-hidden="true"
      className="relative mx-auto w-full max-w-md select-none lg:max-w-none"
    >
      {/* Floating phone card — expressive mobile proof */}
      <figure className="absolute -bottom-7 -start-3 z-10 w-24 border border-border bg-card p-1.5 shadow-[6px_6px_0_0_var(--brand)] sm:-start-7 sm:w-28 lg:w-32">
        <span className="relative block aspect-[9/16] w-full overflow-hidden">
          <Image
            src="/images/phone-site.jpg"
            alt=""
            fill
            sizes="128px"
            className="object-cover"
          />
        </span>
        <figcaption className="bg-deep px-1.5 py-1.5 text-center text-[9px] font-semibold leading-none text-cream sm:text-[10px]">
          {t({ ar: "يعمل على الجوال", en: "Works on mobile" })}
        </figcaption>
      </figure>

      {/* mosaic backdrop squares */}
      <div className="absolute -top-5 end-2 grid grid-cols-3 gap-1.5 sm:-end-5">
        {Array.from({ length: 6 }).map((_, i) => (
          <span
            key={i}
            className={`h-2.5 w-2.5 ${i % 3 === 0 ? "bg-brand/40" : "bg-foreground/10"}`}
          />
        ))}
      </div>

      {/* browser frame */}
      <div className="relative border border-border bg-card shadow-[8px_8px_0_0_var(--brand-soft)]">
        {/* browser bar */}
        <div className="flex items-center gap-2 border-b border-border bg-secondary/70 px-4 py-3">
          <span className="h-2.5 w-2.5 bg-brand" />
          <span className="h-2.5 w-2.5 bg-foreground/25" />
          <span className="ms-3 h-2 w-28 max-w-[40%] bg-border" />
          <span className="ms-auto h-2 w-8 bg-border" />
        </div>

        {/* site header — two small squares like the logo, plus nav lines */}
        <div className="flex items-center justify-between border-b border-border px-5 py-3.5">
          <div className="flex items-center gap-1.5">
            <span className="h-3 w-3 bg-foreground" />
            <span className="h-3 w-3 bg-brand" />
          </div>
          <div className="flex items-center gap-2">
            <span className="h-1.5 w-9 bg-foreground/20" />
            <span className="h-1.5 w-9 bg-foreground/20" />
            <span className="h-1.5 w-9 bg-foreground/20" />
          </div>
        </div>

        {/* page body */}
        <div className="space-y-4 p-5">
          {/* hero block */}
          <div className="border border-border bg-secondary/50 p-4">
            <div className="h-3 w-3/4 bg-foreground/70" />
            <div className="mt-2.5 h-2 w-2/3 bg-foreground/20" />
            <div className="mt-1.5 h-2 w-1/2 bg-foreground/20" />
            <div className="mt-4 flex items-center gap-2">
              <span className="h-6 w-20 bg-brand" />
              <span className="h-6 w-14 border border-border bg-card" />
            </div>
          </div>

          {/* content mosaic — three squared cards */}
          <div className="grid grid-cols-3 gap-3">
            {[0, 1, 2].map((i) => (
              <div key={i} className="border border-border p-3">
                <span
                  className={`block h-3 w-3 ${i === 1 ? "bg-brand" : "bg-foreground/70"}`}
                />
                <span className="mt-2.5 block h-1.5 w-full bg-foreground/15" />
                <span className="mt-1.5 block h-1.5 w-2/3 bg-foreground/15" />
              </div>
            ))}
          </div>

          {/* contact strip */}
          <div className="flex items-center gap-2.5 border-t border-border pt-4">
            <span className="h-1.5 w-1.5 bg-brand" />
            <span className="h-2 w-32 bg-foreground/15" />
            <span className="ms-auto h-2 w-10 bg-foreground/15" />
          </div>
        </div>
      </div>
    </div>
  );
}

export function WhySiteSection() {
  const { t, dir } = useLang();
  const reduce = useReducedMotion();
  const Arrow = dir === "rtl" ? ArrowLeft : ArrowRight;

  const fade = (delay: number) =>
    reduce
      ? {}
      : {
          initial: { opacity: 0, y: 18 },
          whileInView: { opacity: 1, y: 0 },
          viewport: { once: true, margin: "-60px" },
          transition: { duration: 0.55, delay, ease: [0.22, 1, 0.36, 1] as const },
        };

  return (
    <Section
      id="why-site"
      ariaLabel={t({
        ar: "لماذا يحتاج مشروعك إلى موقع",
        en: "Why your project needs a website",
      })}
    >
      <Container>
        <div className="grid items-center gap-12 lg:grid-cols-2 lg:gap-14">
          {/* Text — start side (right in Arabic, left in English) */}
          <motion.div {...fade(0)}>
            <SectionHeading
              eyebrow={t({
                ar: "لماذا يحتاج مشروعك إلى موقع؟",
                en: "Why does your project need a website?",
              })}
              title={t({
                ar: "لأن عملاءك يريدون أن يجدوا إجاباتهم بسهولة.",
                en: "Because your customers want to find their answers easily.",
              })}
              description={t({
                ar: "موقعك يمنح مشروعك مكانًا واضحًا يشرح خدماته، يعرض تفاصيله في أي وقت، ويجمع روابطه ومعلومات التواصل في تجربة واحدة. سواء كنت صاحب شركة أو متجر أو مطعم أو خدمة، يساعدك الموقع على تقديم مشروعك بشكل منظم ويسهّل على العميل معرفة الخطوة التالية.",
                en: "Your website gives your project a clear home that explains its services, shows its details at any time, and brings its links and contact information into one experience. Whether you run a company, a store, a restaurant, or a service, a website helps you present your business in an organized way and makes it easy for customers to know the next step.",
              })}
              className="mb-8 sm:mb-10"
            />

            <ul className="space-y-4">
              {BULLETS.map((b) => {
                const Icon = b.icon;
                return (
                  <li key={b.en} className="flex items-start gap-3.5">
                    <span className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center bg-brand-soft text-foreground">
                      <Icon className="h-4 w-4" aria-hidden="true" />
                    </span>
                    <p className="pt-1.5 text-sm leading-relaxed text-foreground/90 sm:pt-2 sm:text-base">
                      {t({ ar: b.ar, en: b.en })}
                    </p>
                  </li>
                );
              })}
            </ul>

            <div className="mt-9">
              <Button
                size="lg"
                onClick={() => openRequest()}
                className="h-12 rounded-none bg-brand px-6 text-base text-brand-foreground hover:bg-brand/90"
              >
                {t({
                  ar: "اكتشف الموقع المناسب لنشاطي",
                  en: "Discover the right website for my business",
                })}
                <Arrow className="h-4 w-4" aria-hidden="true" />
              </Button>
            </div>
          </motion.div>

          {/* Visual — end side */}
          <motion.div {...fade(0.12)}>
            <WebsiteMockup />
          </motion.div>
        </div>
      </Container>
    </Section>
  );
}
