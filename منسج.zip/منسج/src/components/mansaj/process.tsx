"use client";

import { motion, useReducedMotion } from "framer-motion";
import { useLang } from "@/lib/lang";
import { Container, Section, SectionHeading } from "./shared";

const STEPS = [
  {
    num: "01",
    ar: "نفهم احتياجك",
    en: "Understand your need",
    arDesc: "نعرف طبيعة نشاطك، وجمهورك، وما الذي تريد أن يحققه الموقع.",
    enDesc:
      "We learn the nature of your business, your audience, and what you want the website to achieve.",
  },
  {
    num: "02",
    ar: "نحدد الحل",
    en: "Define the solution",
    arDesc: "نختار نوع الموقع والخدمات والوظائف التي تناسب مشروعك.",
    enDesc:
      "We choose the website type, services, and features that fit your project.",
  },
  {
    num: "03",
    ar: "نصمّم ونطوّر",
    en: "Design & develop",
    arDesc: "نبني تجربة مرتبة ومتجاوبة ونراجع التفاصيل معك.",
    enDesc:
      "We build a tidy, responsive experience and review the details with you.",
  },
  {
    num: "04",
    ar: "نختبر ونسلّم",
    en: "Test & deliver",
    arDesc: "نختبر الروابط والصفحات والوظائف، ثم نسلّم المشروع حسب النطاق المتفق عليه.",
    enDesc:
      "We test the links, pages, and functionality, then deliver the project according to the agreed scope.",
  },
  {
    num: "05",
    ar: "نساندك",
    en: "Support you",
    arDesc: "نناقش خيارات الصيانة والدعم والاستضافة إذا كانت ضمن احتياجك.",
    enDesc:
      "We discuss maintenance, support, and hosting options if they are part of your needs.",
  },
];

export function ProcessSection() {
  const { t } = useLang();
  const reduce = useReducedMotion();

  const fade = (delay: number) =>
    reduce
      ? {}
      : {
          initial: { opacity: 0, y: 18 },
          whileInView: { opacity: 1, y: 0 },
          viewport: { once: true, margin: "-60px" },
          transition: { duration: 0.55, delay, ease: [0.22, 1, 0.36, 1] as const },
        };

  return (
    <Section
      id="process"
      ariaLabel={t({ ar: "طريقة العمل", en: "How we work" })}
    >
      <Container>
        <SectionHeading
          eyebrow={t({ ar: "طريقة العمل", en: "How we work" })}
          title={t({
            ar: "واضحين معك من أول خطوة",
            en: "Clear with you from the first step",
          })}
        />

        <ol className="grid gap-8 lg:grid-cols-5 lg:gap-4">
          {STEPS.map((step, i) => {
            const isLast = i === STEPS.length - 1;
            return (
              <motion.li
                key={step.num}
                {...fade(i * 0.08)}
                className="relative flex flex-col"
              >
                {/* squared step number + horizontal connector (lg) */}
                <div className="flex items-center">
                  <span
                    dir="ltr"
                    className="relative z-10 flex h-14 w-14 shrink-0 items-center justify-center border border-border bg-deep font-mono text-lg font-bold text-deep-foreground shadow-[3px_3px_0_0_var(--brand)]"
                  >
                    {step.num}
                  </span>
                  {!isLast && (
                    <span
                      aria-hidden="true"
                      className="hidden h-px flex-1 bg-border lg:-me-4 lg:block"
                    />
                  )}
                </div>

                {/* vertical connector (mobile / tablet stepped path) */}
                {!isLast && (
                  <span
                    aria-hidden="true"
                    className="absolute -bottom-8 start-7 top-14 w-px bg-border lg:hidden"
                  />
                )}

                <div className="mt-4 ps-[4.5rem] lg:mt-5 lg:ps-0">
                  <h3 className="text-lg font-bold leading-snug">
                    {t({ ar: step.ar, en: step.en })}
                  </h3>
                  <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">
                    {t({ ar: step.arDesc, en: step.enDesc })}
                  </p>
                </div>
              </motion.li>
            );
          })}
        </ol>
      </Container>
    </Section>
  );
}
