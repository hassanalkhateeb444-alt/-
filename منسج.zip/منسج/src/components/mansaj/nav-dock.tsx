"use client";

import { useEffect, useState } from "react";
import { motion, useReducedMotion } from "framer-motion";
import { Menu, PenSquare } from "lucide-react";
import Image from "next/image";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { useLang } from "@/lib/lang";
import { BRAND, NAV_ITEMS } from "./data";
import { openRequest, scrollToSection, WhatsAppIcon } from "./shared";
import { Logo } from "./site-header";
import { cn } from "@/lib/utils";

/* ------------------------------------------------------------------ */
/* Floating nav dock — the menu as a slim bar floating on the          */
/* inline-start edge (right side in Arabic RTL), reachable everywhere. */
/* ------------------------------------------------------------------ */

const dockBtnClass =
  "group relative flex h-10 w-10 shrink-0 items-center justify-center rounded-sm " +
  "text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground " +
  "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring " +
  "after:absolute after:-inset-0.5 after:content-['']";

const dockTipClass =
  "pointer-events-none absolute start-full top-1/2 z-10 hidden ms-2 -translate-y-1/2 " +
  "whitespace-nowrap border border-border bg-deep px-2 py-1 text-[11px] font-semibold " +
  "text-deep-foreground opacity-0 shadow-sm transition-opacity duration-150 lg:block " +
  "group-hover:opacity-100 group-focus-visible:opacity-100";

export function NavDock() {
  const { t, dir } = useLang();
  const reduce = useReducedMotion();
  const [active, setActive] = useState("home");
  const [open, setOpen] = useState(false);

  /* Scroll spy — highlight the section currently in view. */
  useEffect(() => {
    const ids = NAV_ITEMS.map((i) => i.id);
    let raf = 0;
    const compute = () => {
      raf = 0;
      const probe = window.innerHeight * 0.4;
      let current = ids[0];
      for (const id of ids) {
        const el = document.getElementById(id);
        if (!el) continue;
        if (el.getBoundingClientRect().top <= probe) current = id;
      }
      const atBottom =
        window.innerHeight + window.scrollY >=
        document.documentElement.scrollHeight - 4;
      if (atBottom) current = ids[ids.length - 1];
      setActive((prev) => (prev === current ? prev : current));
    };
    const onScroll = () => {
      if (!raf) raf = requestAnimationFrame(compute);
    };
    compute();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      if (raf) cancelAnimationFrame(raf);
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
    };
  }, []);

  const go = (id: string) => {
    setOpen(false);
    scrollToSection(id);
  };

  return (
    <nav
      aria-label={t({ ar: "القائمة العائمة", en: "Floating menu" })}
      className="fixed start-2 top-1/2 z-40 -translate-y-1/2 sm:start-3"
    >
      <motion.div
        initial={reduce ? false : { opacity: 0, x: dir === "rtl" ? 24 : -24 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.5, delay: 0.35, ease: [0.22, 1, 0.36, 1] }}
        className="flex max-h-[calc(100dvh-2rem)] flex-col items-stretch gap-1 rounded-sm border border-border bg-card/85 p-1.5 shadow-[4px_4px_0_0_var(--brand-soft)] backdrop-blur-md max-lg:overflow-y-auto max-lg:[scrollbar-width:none] max-lg:[&::-webkit-scrollbar]:hidden"
      >
        {/* Full menu trigger — opens the complete navigation sheet */}
        <Sheet open={open} onOpenChange={setOpen}>
          <SheetTrigger asChild>
            <button
              type="button"
              aria-label={t({ ar: "فتح القائمة الكاملة", en: "Open the full menu" })}
              aria-expanded={open}
              className={dockBtnClass}
            >
              <Menu className="h-4 w-4" aria-hidden="true" />
              <span aria-hidden="true" className={dockTipClass}>
                {t({ ar: "القائمة الكاملة", en: "Full menu" })}
              </span>
            </button>
          </SheetTrigger>
          <SheetContent
            side={dir === "rtl" ? "right" : "left"}
            aria-describedby={undefined}
            className="flex w-[85vw] max-w-sm flex-col gap-0 overflow-y-auto p-0"
          >
            <SheetHeader className="border-b border-border p-4 text-start">
              <SheetTitle asChild>
                <div>
                  <Logo />
                </div>
              </SheetTitle>
            </SheetHeader>
            <nav
              aria-label={t({ ar: "قائمة التنقل الكاملة", en: "Full navigation" })}
              className="flex-1 p-4"
            >
              <ul className="flex flex-col gap-1">
                {NAV_ITEMS.map((item) => (
                  <li key={item.id}>
                    <button
                      type="button"
                      onClick={() => go(item.id)}
                      aria-current={active === item.id ? "true" : undefined}
                      className={cn(
                        "flex min-h-[44px] w-full items-center gap-3 rounded-sm px-3 py-2.5 text-start text-sm font-medium transition-colors hover:bg-secondary",
                        active === item.id && "bg-secondary font-semibold"
                      )}
                    >
                      <item.icon
                        className="h-4 w-4 shrink-0 text-brand"
                        aria-hidden="true"
                      />
                      {t({ ar: item.ar, en: item.en })}
                      <span
                        className="ms-auto font-mono text-xs text-muted-foreground"
                        dir="ltr"
                      >
                        {String(NAV_ITEMS.indexOf(item) + 1).padStart(2, "0")}
                      </span>
                    </button>
                  </li>
                ))}
              </ul>
            </nav>
            <div className="border-t border-border p-4">
              <Button
                onClick={() => {
                  setOpen(false);
                  openRequest();
                }}
                className="w-full rounded-sm font-semibold"
              >
                {t({ ar: "أريد موقعًا لمشروعي", en: "I want a website" })}
              </Button>
              <a
                href={`https://wa.me/967771648640`}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-3 flex w-full items-center justify-center gap-2 rounded-sm border border-border px-4 py-2.5 text-sm font-medium transition-colors hover:bg-secondary"
              >
                <WhatsAppIcon className="h-4 w-4 text-brand" />
                {t({ ar: "تواصل مباشر عبر واتساب", en: "Chat on WhatsApp" })}
              </a>
              <p className="mt-4 flex items-center justify-center gap-2 text-xs text-muted-foreground">
                <Image
                  src="/images/mansaj-logo.png"
                  alt=""
                  aria-hidden="true"
                  width={16}
                  height={16}
                  className="h-4 w-4 object-contain"
                />
                {t({ ar: BRAND.ar, en: BRAND.en })}
              </p>
            </div>
          </SheetContent>
        </Sheet>

        <span
          aria-hidden="true"
          className="mx-2 h-px shrink-0 bg-border"
        />

        {/* Section shortcuts */}
        {NAV_ITEMS.map((item) => {
          const isActive = active === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => go(item.id)}
              aria-label={t({ ar: item.ar, en: item.en })}
              aria-current={isActive ? "true" : undefined}
              className={cn(
                dockBtnClass,
                isActive &&
                  "bg-brand text-brand-foreground hover:bg-brand hover:text-brand-foreground"
              )}
            >
              <item.icon className="h-4 w-4" aria-hidden="true" />
              <span aria-hidden="true" className={dockTipClass}>
                {t({ ar: item.ar, en: item.en })}
              </span>
            </button>
          );
        })}

        <span
          aria-hidden="true"
          className="mx-2 h-px shrink-0 bg-border"
        />

        {/* Quick request CTA */}
        <button
          type="button"
          onClick={() => openRequest()}
          aria-label={t({ ar: "ابدأ مشروعك الآن", en: "Start your project" })}
          className={cn(dockBtnClass, "text-brand hover:text-brand")}
        >
          <PenSquare className="h-4 w-4" aria-hidden="true" />
          <span aria-hidden="true" className={dockTipClass}>
            {t({ ar: "ابدأ مشروعك", en: "Start your project" })}
          </span>
        </button>
      </motion.div>
    </nav>
  );
}
