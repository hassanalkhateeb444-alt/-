"use client";

import Image from "next/image";
import { motion, useReducedMotion } from "framer-motion";
import { useLang } from "@/lib/lang";
import {
  Container,
  CountUp,
  MosaicMark,
  Section,
  SectionHeading,
} from "./shared";
import { STATS } from "./data";

export function WhyMansajSection() {
  const { t } = useLang();
  const reduce = useReducedMotion();

  const fade = (delay: number) =>
    reduce
      ? {}
      : {
          initial: { opacity: 0, y: 18 },
          whileInView: { opacity: 1, y: 0 },
          viewport: { once: true, margin: "-60px" },
          transition: { duration: 0.55, delay, ease: [0.22, 1, 0.36, 1] as const },
        };

  return (
    <Section
      id="why-mansaj"
      ariaLabel={t({ ar: "لماذا منسج", en: "Why Mansaj" })}
    >
      <Container>
        <SectionHeading
          eyebrow={t({ ar: "لماذا منسج؟", en: "Why Mansaj?" })}
          title={t({
            ar: "لا نبني صفحات فقط؛ نبني تجربة تناسب هدف مشروعك.",
            en: "We don't just build pages; we build an experience that fits your project's goal.",
          })}
          description={t({
            ar: "في منسج نبدأ من احتياج النشاط، ثم نختار نوع الموقع والمحتوى والوظائف التي تخدمه. نركز على وضوح التجربة وسهولة استخدامها على الهاتف، ونرافقك بخطوات متفق عليها من بداية المشروع حتى التسليم.",
            en: "At Mansaj we start from what your business needs, then choose the website type, content, and features that serve it. We focus on a clear experience that is easy to use on the phone, and we walk with you through agreed steps from the start of the project until delivery.",
          })}
          className="mb-10 sm:mb-12"
        />
      </Container>

      {/* Expressive visual — from the idea to the implementation */}
      <Container className="mb-10 sm:mb-12">
        <motion.figure
          {...fade(0.1)}
          className="group relative overflow-hidden border border-border bg-card shadow-[6px_6px_0_0_var(--brand-soft)] transition-shadow hover:shadow-[6px_6px_0_0_var(--brand)]"
        >
          <div className="relative aspect-[16/9] sm:aspect-[16/6.4]">
            <Image
              src="/images/dev-work.jpg"
              alt={t({
                ar: "مطوّرة تبني موقعًا على حاسوبها المحمول",
                en: "A developer building a website on her laptop",
              })}
              fill
              sizes="(max-width: 896px) 100vw, 1152px"
              className="object-cover transition-transform duration-500 group-hover:scale-[1.02]"
            />
            <div
              aria-hidden="true"
              className="absolute inset-0 bg-gradient-to-t from-deep/60 via-transparent to-transparent"
            />
            <figcaption className="absolute bottom-3 start-4 bg-deep/85 px-3 py-1.5 text-xs font-semibold text-cream backdrop-blur-sm sm:text-sm">
              {t({
                ar: "من الفكرة إلى التنفيذ — بخطوات واضحة ومتفق عليها",
                en: "From the idea to the implementation — clear, agreed steps",
              })}
            </figcaption>
          </div>
        </motion.figure>
      </Container>

      {/* Trust panel — full-bleed deep strip with blueprint grid */}
      <div className="relative bg-deep text-deep-foreground">
        <div aria-hidden="true" className="bg-blueprint absolute inset-0 opacity-60" />
        <Container className="relative py-10 sm:py-12">
          <div className="relative grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4 lg:gap-5">
            {STATS.map((s, i) => (
              <motion.div
                key={s.en}
                {...fade(0.08 + i * 0.08)}
                className="relative border border-deep-foreground/15 bg-deep-foreground/[0.04] p-5 sm:p-6"
              >
                <span aria-hidden="true" className="block h-1.5 w-1.5 bg-brand" />
                <p className="mt-4 text-3xl font-bold tracking-tight text-brand sm:text-4xl">
                  <CountUp to={s.value} suffix={s.suffix} />
                </p>
                <p className="mt-2 text-sm leading-relaxed text-deep-foreground/80">
                  {t({ ar: s.ar, en: s.en })}
                </p>
              </motion.div>
            ))}
          </div>
          {/* geometric corner accent */}
          <MosaicMark
            className="absolute end-1 top-1 hidden h-8 w-10 text-deep-foreground/20 lg:block"
            accentClassName="opacity-90"
          />
        </Container>
      </div>
    </Section>
  );
}
